/*
* Copyright(C) 2010,Hikvision Digital Technology Co., Ltd 
* 
* File   name��CapPicture.h
* Discription��
* Version    ��1.0
* Author     ��panyd
* Create Date��2010_3_25
* Modification History��
*/

int Demo_Capture(char* uname, char* pass, char* ip, char* dir);
