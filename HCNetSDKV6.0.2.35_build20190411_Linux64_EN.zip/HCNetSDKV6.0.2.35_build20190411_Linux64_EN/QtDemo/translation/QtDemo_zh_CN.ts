<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>AddNodeClass</name>
    <message>
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="14"/>
        <source>AddNode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="88"/>
        <source>get ip address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="111"/>
        <source>IP Server port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="137"/>
        <source>device ip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="150"/>
        <source>cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="163"/>
        <source>node name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="189"/>
        <source>port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="202"/>
        <source>ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="268"/>
        <source>get device ip from ip server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="281"/>
        <source>password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="294"/>
        <source>device serial number</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="307"/>
        <source>IP Server address：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="330"/>
        <source>device name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/AddNode/addnode.ui" line="366"/>
        <source>username</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>获取地址</source>
        <translation type="obsolete">Get ip address</translation>
    </message>
    <message utf8="true">
        <source>IP Server上的端口号：</source>
        <translation type="obsolete">IP Server上的端口号</translation>
    </message>
</context>
<context>
    <name>AlarmTableClass</name>
    <message>
        <location filename="../src/MainWindow/LogAlarm/AlarmTable/alarmtable.ui" line="14"/>
        <source>AlarmTable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/LogAlarm/AlarmTable/alarmtable.ui" line="27"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/LogAlarm/AlarmTable/alarmtable.ui" line="32"/>
        <source>alarm info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/LogAlarm/AlarmTable/alarmtable.ui" line="37"/>
        <source>device info</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioBroadcastClass</name>
    <message>
        <location filename="../src/OtherFunc/AudioBroadcast/audiobroadcast.ui" line="14"/>
        <source>AudioBroadcast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioBroadcast/audiobroadcast.ui" line="41"/>
        <source>start broadcast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioBroadcast/audiobroadcast.ui" line="54"/>
        <source>exit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioIntercomClass</name>
    <message>
        <location filename="../src/OtherFunc/AudioIntercom/audiointercom.ui" line="14"/>
        <source>AudioIntercom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioIntercom/audiointercom.ui" line="26"/>
        <source>start talk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioIntercom/audiointercom.ui" line="39"/>
        <source>audio talk channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioIntercom/audiointercom.ui" line="52"/>
        <source>state:used/unused</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioIntercom/audiointercom.ui" line="65"/>
        <source>stop talk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioIntercom/audiointercom.ui" line="104"/>
        <source>exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioIntercom/audiointercom.ui" line="153"/>
        <source>callback data type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioIntercom/audiointercom.ui" line="176"/>
        <source>update</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioTransfer</name>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="359"/>
        <source>Find Update Files DIR and Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="422"/>
        <source>NET_DVR_StartVoiceCom_MR_V30 error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="423"/>
        <source>m_atindex=%1 m_atuserid[m_atindex]=%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="428"/>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="429"/>
        <source>NET_DVR_StartVoiceCom_MR_V30 SUCC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="439"/>
        <source>NET_DVR_StopVoiceCom error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="440"/>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="492"/>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="504"/>
        <source>lasterror=%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="444"/>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="445"/>
        <source>NET_DVR_StopVoiceCom SUCC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="458"/>
        <source>NET_DVR_InitG722Encoder error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="459"/>
        <source>LAST_ERROR=%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="464"/>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="465"/>
        <source>NET_DVR_InitG722Encoder SUCC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="477"/>
        <source>ÒôÆµÎÄ¼þ´íÎó</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="478"/>
        <source>ÒôÆµÎÄ¼þ²ÎÊý´íÎó</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="491"/>
        <source>NET_DVR_EncodeG722Frame error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="496"/>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="497"/>
        <source>NET_DVR_EncodeG722Frame SUCC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="503"/>
        <source>NET_DVR_VoiceComSendData error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="514"/>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.cpp" line="515"/>
        <source>NET_DVR_VoiceComSendData SUCC</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioTransferClass</name>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="14"/>
        <source>AudioTransfer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="78"/>
        <source>eixt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="92"/>
        <source>device tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="106"/>
        <source>browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="119"/>
        <source>send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="142"/>
        <source>audio file path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="155"/>
        <source>start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="168"/>
        <source>stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="182"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="187"/>
        <source>handle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="192"/>
        <source>size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="197"/>
        <source>type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="202"/>
        <source>user data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/AudioTransfer/audiotransfer.ui" line="216"/>
        <source>receive data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CATMNetParamsClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="14"/>
        <source>CATMNetParams</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="26"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;报文标志位:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="46"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="112"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="156"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="200"/>
        <source>长度</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="68"/>
        <source>内容</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="90"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="134"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="178"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="295"/>
        <source>起始位置</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="219"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;卡号长度信息:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="236"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;卡号信息:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="253"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;交易类型:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="273"/>
        <source>ATM类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="317"/>
        <source>代码</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="339"/>
        <source>类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmnetparams.ui" line="361"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;ATM IP地址&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CATMParams</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmparams.cpp" line="133"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmparams.cpp" line="185"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmparams.cpp" line="223"/>
        <source>The error is &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CATMParamsClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmparams.ui" line="14"/>
        <source>CATMParams</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmparams.ui" line="66"/>
        <source>本地端口:</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmparams.ui" line="89"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;ATM类型:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ATMParams/catmparams.ui" line="136"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;输入方式&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CAdvancedNetParams</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="97"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="349"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="437"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="476"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="571"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="576"/>
        <source>Please check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="97"/>
        <source>Get PPPoE information unsuccessfully! error:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="238"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="457"/>
        <source>Set Net fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="238"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="457"/>
        <source>Set Net fail. &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="320"/>
        <source>Device params error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="349"/>
        <source>Double DDNS passwd is not equal!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="375"/>
        <source>Set DDNS fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="375"/>
        <source>Set DDNS fail. &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="387"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="407"/>
        <source>Please check.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="387"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="407"/>
        <source>User ID is wrong!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="437"/>
        <source>Double is net equal!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="476"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="571"/>
        <source>.Get Email information unsuccessfully!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="576"/>
        <source>Double Email passwd is net equal!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="638"/>
        <source>Set Email fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.cpp" line="638"/>
        <source>Set Email fail. &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CAdvancedNetParamsClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="14"/>
        <source>CAdvancedNetParams</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="29"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; color:#0000ff;&quot;&gt;PPPoE config&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="59"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; color:#0000ff;&quot;&gt;Email setup&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="86"/>
        <source>save parameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="99"/>
        <source>enable PPPoE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="112"/>
        <source>enable NTP time corrention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="138"/>
        <source>quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="154"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="542"/>
        <source>username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="164"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="552"/>
        <source>password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="174"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="287"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="562"/>
        <source>confirm password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="196"/>
        <source>setup interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="206"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="329"/>
        <source>min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="225"/>
        <source>NTP server address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="235"/>
        <source>NTP port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="257"/>
        <source>PPPoE username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="267"/>
        <source>PPPoE password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="277"/>
        <source>PPPoE address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="309"/>
        <source>time difference with UTC </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="319"/>
        <source>h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="345"/>
        <source>enable domain analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="361"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; color:#0000ff;&quot;&gt;DDNS config&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="394"/>
        <source>device alias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="413"/>
        <source>port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="437"/>
        <source>server type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="451"/>
        <source>domain name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="475"/>
        <source>interval of sending Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="497"/>
        <source>E-mail receiver info(3 accounts)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="526"/>
        <source>update</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="584"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; color:#0000ff;&quot;&gt;NTP config&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="614"/>
        <source>sender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="624"/>
        <source>E-mail address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="634"/>
        <source>smtp server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="644"/>
        <source>smtp port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="666"/>
        <source>pop3 server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="691"/>
        <source>server need certification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="707"/>
        <source>send attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cadvancednetparams.ui" line="723"/>
        <source>enable SSL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CAlarmInHandleTypeClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="14"/>
        <source>CAlarmInHandleType</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="32"/>
        <source>触发报警输出</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="48"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="76"/>
        <source>时间段1</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="83"/>
        <source>时间段2</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="90"/>
        <source>时间段3</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="97"/>
        <source>时间段4</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="104"/>
        <source>时间段5</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="111"/>
        <source>时间段6</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="118"/>
        <source>时间段7</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="125"/>
        <source>时间段8</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="136"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="143"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="150"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="157"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="164"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="171"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="178"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="185"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="322"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="329"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="336"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="343"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="350"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="357"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="364"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="371"/>
        <source>时</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="199"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="206"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="213"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="220"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="227"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="234"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="241"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="248"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="385"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="392"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="399"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="406"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="413"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="420"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="427"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="434"/>
        <source>分</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="259"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="266"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="273"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="280"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="287"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="294"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="301"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="308"/>
        <source>---</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="455"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;触发录像通道&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="472"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;布防时间&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="505"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;日期&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="531"/>
        <source>监视器上报警   </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="538"/>
        <source>声音警告</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="545"/>
        <source>上传中心</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="552"/>
        <source>Email JPEG     </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminhandletype.ui" line="568"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;报警处理方式&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CAlarmInPTZClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminptz.ui" line="14"/>
        <source>CAlarmInPTZ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminptz.ui" line="29"/>
        <source>预置点</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminptz.ui" line="39"/>
        <source>巡航</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminptz.ui" line="49"/>
        <source>轨迹</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminptz.ui" line="71"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;通道号&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminptz.ui" line="97"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarminptz.ui" line="104"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CAlarmParamsDlg</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.cpp" line="237"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.cpp" line="242"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.cpp" line="237"/>
        <source>NET_DVR_GET_IPALARMINCFG failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.cpp" line="242"/>
        <source>NET_DVR_GET_IPALARMOUTCFG failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.cpp" line="342"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.cpp" line="370"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.cpp" line="455"/>
        <source>Please check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.cpp" line="342"/>
        <source>Get alarm in parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.cpp" line="370"/>
        <source>Get alarm out parameters error! </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.cpp" line="455"/>
        <source>Set alarm out parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="26"/>
        <source>报警输入设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="38"/>
        <source>PTZ联动</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="51"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="936"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="67"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;报警输入名称&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="93"/>
        <source>报警处理</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="100"/>
        <source>设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="119"/>
        <source>报警器类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="127"/>
        <source>常开</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="132"/>
        <source>常闭</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="152"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;报警输入  &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="180"/>
        <source>IP设备地址</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="200"/>
        <source>IP输入通道  </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="229"/>
        <source>报警输出设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="241"/>
        <source>报警输出触发时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="253"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="293"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="320"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="365"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="392"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="431"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="458"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="497"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="524"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="563"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="583"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="629"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="649"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="695"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="722"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="758"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="785"/>
        <source>分</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="279"/>
        <source>时间段2</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="286"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="310"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="355"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="382"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="421"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="448"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="487"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="514"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="553"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="590"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="619"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="639"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="685"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="712"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="748"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="775"/>
        <source>时</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="300"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="372"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="438"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="504"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="570"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="656"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="702"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="765"/>
        <source>--</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="345"/>
        <source>时间段8</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="411"/>
        <source>时间段6</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="477"/>
        <source>时间段3</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="543"/>
        <source>时间段1</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="609"/>
        <source>时间段4</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="675"/>
        <source>时间段5</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="741"/>
        <source>时间段7</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="804"/>
        <source>确定日期设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="820"/>
        <source>日期</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="828"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="885"/>
        <source>星期一</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="833"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="890"/>
        <source>星期二</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="838"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="895"/>
        <source>星期三</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="843"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="900"/>
        <source>星期四</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="848"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="905"/>
        <source>星期五</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="853"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="910"/>
        <source>星期六</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="858"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="915"/>
        <source>星期天</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="880"/>
        <source>整个星期</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="921"/>
        <source>复制</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="952"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;报警输出&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="966"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;IP设备地址&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="980"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;IP输出通道&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="994"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;报警输出名称&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="1012"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;输出报警延时&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="1024"/>
        <source>5秒</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="1029"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="1054"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="1034"/>
        <source>30</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="1039"/>
        <source>1分钟</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="1044"/>
        <source>2分钟</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="1049"/>
        <source>5分钟</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="1059"/>
        <source>自定义</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/AlarmParams/calarmparamsdlg.ui" line="1067"/>
        <source>触发报警输出</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CChannelParams</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="233"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="337"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="382"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="409"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="440"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="505"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="558"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="588"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="715"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="831"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="867"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="900"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1088"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1141"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1164"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1182"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1197"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1216"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1234"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1253"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1271"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1288"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1312"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1330"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1347"/>
        <source>Please check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="233"/>
        <source>Get device parameters error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="337"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="382"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="440"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="505"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="588"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="715"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1141"/>
        <source>Get press parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="409"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="558"/>
        <source>Set press parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="831"/>
        <source>Get Picture parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="867"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1088"/>
        <source>Get show strings parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="900"/>
        <source>Set show strings parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1164"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1216"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1253"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1312"/>
        <source>User ID error! </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1182"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1234"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1271"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1330"/>
        <source>Get picture parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1197"/>
        <source>Get device parameters error1! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1288"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1347"/>
        <source>Get device parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1530"/>
        <source>Please login firstly!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.cpp" line="1530"/>
        <source>User ID is not correct!.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CChannelParamsClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="14"/>
        <source>CChannelParams</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="26"/>
        <source>channel No.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="52"/>
        <source>stream mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="59"/>
        <source>max bitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="66"/>
        <source>audio format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="148"/>
        <source>channel name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="210"/>
        <source>image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="217"/>
        <source>frame rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="224"/>
        <source>video format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="243"/>
        <source>encoding parameter type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="265"/>
        <source>resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="272"/>
        <source>I frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="309"/>
        <source>bitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="316"/>
        <source>BP frame </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="350"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; color:#0000ff;&quot;&gt;encoding parameter setup&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="380"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;record parameter&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="410"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;image parameter setup&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="445"/>
        <source>schedule record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="452"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="567"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="581"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="663"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="677"/>
        <source>setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="463"/>
        <source>save duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="473"/>
        <source>day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="496"/>
        <source>pre-record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="508"/>
        <source>redundancy record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="529"/>
        <source>delay record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="541"/>
        <source>record audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="560"/>
        <source>motion detect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="574"/>
        <source>mask alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="600"/>
        <source>diaplay channel name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="609"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="757"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="864"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="619"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="767"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="874"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="640"/>
        <source>add OSD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="656"/>
        <source>mask</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="670"/>
        <source>video loss alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="696"/>
        <source>brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="706"/>
        <source>contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="716"/>
        <source>saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="726"/>
        <source>hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="748"/>
        <source>display OSD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="791"/>
        <source>display week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="798"/>
        <source>time format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="832"/>
        <source>OS property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="842"/>
        <source>date format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="896"/>
        <source>contest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="920"/>
        <source>display area   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="932"/>
        <source>enable diaplay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cchannelparams.ui" line="167"/>
        <source>kbps</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CCompressAudio</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/ccompressaudio.cpp" line="58"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/ccompressaudio.cpp" line="67"/>
        <source>Please check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/ccompressaudio.cpp" line="58"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/ccompressaudio.cpp" line="67"/>
        <source>Get Audio information unsuccessfully!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CCompressAudioClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/ccompressaudio.ui" line="14"/>
        <source>CCompressAudio</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/ccompressaudio.ui" line="26"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/ccompressaudio.ui" line="39"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/ccompressaudio.ui" line="52"/>
        <source>刷新</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/ccompressaudio.ui" line="75"/>
        <source>语音对讲音频编码类型</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CConfigureParams</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/cconfigureparams.cpp" line="174"/>
        <source>Login failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/cconfigureparams.cpp" line="174"/>
        <source>&quot;%1&quot; is return value of net_dvr_login.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/cconfigureparams.ui" line="14"/>
        <source>CConfigureParams</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/cconfigureparams.ui" line="26"/>
        <source>remote config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/cconfigureparams.ui" line="39"/>
        <source>local config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/cconfigureparams.ui" line="52"/>
        <source>IPC managememnt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/cconfigureparams.ui" line="65"/>
        <source>disk management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/cconfigureparams.ui" line="89"/>
        <source>login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/cconfigureparams.ui" line="102"/>
        <source>exit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CDlgRemoteRecordSchedule</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.cpp" line="47"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.cpp" line="104"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.cpp" line="202"/>
        <source>Please check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.cpp" line="47"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.cpp" line="104"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.cpp" line="202"/>
        <source>the m_pstruRecord is null!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CDlgRemoteRecordScheduleClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="14"/>
        <source>CDlgRemoteRecordSchedule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="39"/>
        <source>confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="57"/>
        <source>date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="69"/>
        <source>all day record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="78"/>
        <source>record type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="102"/>
        <source>copy to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="112"/>
        <source>copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="128"/>
        <source>start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="141"/>
        <source>end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="159"/>
        <source>period1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="166"/>
        <source>period2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="173"/>
        <source>period3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="180"/>
        <source>period4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="187"/>
        <source>period5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="194"/>
        <source>period6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="201"/>
        <source>period7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="208"/>
        <source>period8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="222"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="229"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="236"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="243"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="250"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="257"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="264"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="271"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="408"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="415"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="422"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="429"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="436"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="443"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="450"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="457"/>
        <source>h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="285"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="292"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="299"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="306"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="313"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="320"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="327"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="334"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="471"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="478"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="485"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="492"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="499"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="506"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="513"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="520"/>
        <source>min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="541"/>
        <source>record mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="345"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="352"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="359"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="366"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="373"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="380"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="387"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cdlgremoterecordschedule.ui" line="394"/>
        <source>---</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CFramePlayWndClass</name>
    <message>
        <location filename="../src/RealPlay/FramePlayWnd.ui" line="14"/>
        <source>CFramePlayWnd</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CHardDiskParams</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.cpp" line="55"/>
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.cpp" line="157"/>
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.cpp" line="179"/>
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.cpp" line="202"/>
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.cpp" line="246"/>
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.cpp" line="273"/>
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.cpp" line="321"/>
        <source>The error is &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.cpp" line="167"/>
        <source>Please check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.cpp" line="167"/>
        <source>Please table widget is NULL!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CHardDiskParamsClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.ui" line="14"/>
        <source>CHardDiskParams</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.ui" line="26"/>
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.ui" line="115"/>
        <source>设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.ui" line="42"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:12pt; color:#0000ff;&quot;&gt;硬盘管理&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.ui" line="79"/>
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.ui" line="102"/>
        <source>刷新</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.ui" line="131"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:12pt; color:#0000ff;&quot;&gt;盘组管理&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.ui" line="161"/>
        <source>盘组号</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/HardDiskParams/charddiskparams.ui" line="180"/>
        <source>选中所有通道</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CHideAlarmClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="14"/>
        <source>CHideAlarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="31"/>
        <source>Period1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="38"/>
        <source>Period2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="45"/>
        <source>Period3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="52"/>
        <source>Period4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="59"/>
        <source>Period5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="66"/>
        <source>Period6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="73"/>
        <source>Period7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="80"/>
        <source>Period8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="91"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="98"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="105"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="112"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="119"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="126"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="133"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="140"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="277"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="284"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="291"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="298"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="305"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="312"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="319"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="326"/>
        <source>h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="154"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="161"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="168"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="175"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="182"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="189"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="196"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="203"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="340"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="347"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="354"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="361"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="368"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="375"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="382"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="389"/>
        <source>min</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="423"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;Guard time&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="440"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;Mask area&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="460"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="482"/>
        <source>Show alarm on monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="489"/>
        <source>Audio alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="496"/>
        <source>Repert to center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="522"/>
        <source>trigger alarm out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="541"/>
        <source>confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="557"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="567"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="577"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="587"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="606"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#ff0000;&quot;&gt;(Size：704*576)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="214"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="221"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="228"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="235"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="242"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="249"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="256"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="263"/>
        <source>---</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/chidealarm.ui" line="503"/>
        <source>Email JPEG     </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CIPParams</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="296"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="303"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="335"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="369"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="375"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="391"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="411"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="428"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="448"/>
        <source>Please check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="296"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="369"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="411"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="448"/>
        <source>Set User parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="303"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="375"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="391"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="428"/>
        <source>Please choose a row of table!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="335"/>
        <source>Please ip device ID is error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="472"/>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.cpp" line="493"/>
        <source>The error is &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CIPParamsClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="14"/>
        <source>CIPParams</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="64"/>
        <source>用户名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="71"/>
        <source>adimin</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="78"/>
        <source>密码</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="85"/>
        <source>12345</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="104"/>
        <source>IP地址</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="111"/>
        <source>172.7.160.2</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="118"/>
        <source>端口</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="125"/>
        <source>8000</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="132"/>
        <source>通道号</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="139"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="158"/>
        <source>添加</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="165"/>
        <source>删除</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="197"/>
        <source>启用</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="204"/>
        <source>禁用</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="224"/>
        <source>更新</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/IPParams/cipparams.ui" line="231"/>
        <source>保存</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CMotionClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="14"/>
        <source>CMotion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="49"/>
        <source>show on monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="56"/>
        <source>audio alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="63"/>
        <source>report to center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="92"/>
        <source>trigger alarm out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="113"/>
        <source>period1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="120"/>
        <source>period2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="127"/>
        <source>period3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="134"/>
        <source>period4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="141"/>
        <source>period5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="148"/>
        <source>period6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="155"/>
        <source>period7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="162"/>
        <source>period8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="173"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="180"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="187"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="194"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="201"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="208"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="215"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="222"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="359"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="366"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="373"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="380"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="387"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="394"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="401"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="408"/>
        <source>h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="236"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="243"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="250"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="257"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="264"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="271"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="278"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="285"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="422"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="429"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="436"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="443"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="450"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="457"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="464"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="471"/>
        <source>min</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="492"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;Guard time&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="522"/>
        <source>confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="538"/>
        <source>date</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="557"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;Motion detect area&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="577"/>
        <source>Sensitivity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="602"/>
        <source>Precision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="70"/>
        <source>Email JPEG     </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="296"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="303"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="310"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="317"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="324"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="331"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="338"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cmotion.ui" line="345"/>
        <source>---</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CNfsParams</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cnfsparams.cpp" line="66"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cnfsparams.cpp" line="129"/>
        <source>Please check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cnfsparams.cpp" line="66"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cnfsparams.cpp" line="129"/>
        <source>Get params error, please click update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cnfsparams.cpp" line="123"/>
        <source>Set NFS fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cnfsparams.cpp" line="123"/>
        <source>Set NFS fail. &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CNfsParamsClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cnfsparams.ui" line="14"/>
        <source>CNfsParams</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cnfsparams.ui" line="26"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cnfsparams.ui" line="39"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cnfsparams.ui" line="57"/>
        <source>服务器IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cnfsparams.ui" line="71"/>
        <source>文件路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cnfsparams.ui" line="95"/>
        <source>磁盘号</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/cnfsparams.ui" line="114"/>
        <source>刷新</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CPPPCfgDlg</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="26"/>
        <source>PPP模式</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="39"/>
        <source>回拨模式</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="52"/>
        <source>用户名</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="65"/>
        <source>密码</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="78"/>
        <source>校验</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="91"/>
        <source>远端IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="104"/>
        <source>本地IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="117"/>
        <source>掩码</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="130"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="143"/>
        <source>电话号码</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="156"/>
        <source>数据加密</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="169"/>
        <source>回拨</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="183"/>
        <source>主动</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="188"/>
        <source>被动</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="203"/>
        <source>拨入者指定</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="208"/>
        <source>预置回拨号</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="297"/>
        <source>设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cpppcfgdlg.ui" line="310"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CRemoteParams</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="140"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="172"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="198"/>
        <source>allocate memory error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="140"/>
        <source>When new m_pChannelParams, error happens.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="172"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="198"/>
        <source>When new m_pUserParams, error happens.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="617"/>
        <source>Net IP ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="617"/>
        <source>Net IP ERROR, please check ip!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="625"/>
        <source>Net Mask ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="625"/>
        <source>Net Mask ERROR, please check mask!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="633"/>
        <source>Net Gateway ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="633"/>
        <source>Net Gateway ERROR, please check Gateway!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="641"/>
        <source>Net DNS1 ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="641"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="649"/>
        <source>Net DNS ERROR, please check DNS!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="649"/>
        <source>Net DNS2 ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="673"/>
        <source>Multicast ip ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="673"/>
        <source>Multicast ip ERROR, please check ip!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="680"/>
        <source>Alarm ip ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="680"/>
        <source>Alarm ip ERROR, please check ip!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="694"/>
        <source>Set Net fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="694"/>
        <source>Set Net fail. &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="717"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="743"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="754"/>
        <source>Please check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="717"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="743"/>
        <source>Get scale parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="754"/>
        <source>Set scale parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="788"/>
        <source>Create advanced net form failly!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="788"/>
        <source>error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="812"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="837"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="860"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="883"/>
        <source>New error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="812"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="837"/>
        <source>new CNfsParams error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="860"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.cpp" line="883"/>
        <source>new CRtspParams error!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CRemoteParamsClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="38"/>
        <source>device setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="50"/>
        <source>advanced network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="69"/>
        <source>hardware version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="79"/>
        <source>DPS software </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="86"/>
        <source>front panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="99"/>
        <source>firmware version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="118"/>
        <source>network adapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="125"/>
        <source>enable get IP address auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="132"/>
        <source>IP address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="142"/>
        <source>subnet mask</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="152"/>
        <source>gateway address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="162"/>
        <source>prefered DDNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="172"/>
        <source>alternate DDNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="182"/>
        <source>physical address</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="214"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; color:#0000ff;&quot;&gt;basic config info&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="244"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; color:#0000ff;&quot;&gt;device version&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="276"/>
        <source>device name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="286"/>
        <source>channel num</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="296"/>
        <source>alarm in num</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="306"/>
        <source>loop record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="320"/>
        <source>device type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="327"/>
        <source>disk num</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="337"/>
        <source>alarm out num</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="347"/>
        <source>IR control ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="374"/>
        <source>enable preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="383"/>
        <source>main</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="393"/>
        <source>spot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="417"/>
        <source>device SN</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="439"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:10pt;&quot;&gt;network config info&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="469"/>
        <source>private domain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="479"/>
        <source>communicate port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="489"/>
        <source>HTTP port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="499"/>
        <source>multicast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="509"/>
        <source>alarm host address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="519"/>
        <source>alarm host port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="529"/>
        <source>MTU size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="548"/>
        <source>NFS setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="561"/>
        <source>time zone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="574"/>
        <source>RTSP setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="587"/>
        <source>audio talk code setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="593"/>
        <source>channel setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="609"/>
        <source>serial port setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="625"/>
        <source>alarm setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="641"/>
        <source>user setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="657"/>
        <source>exception setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="673"/>
        <source>transacation setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="698"/>
        <source>updata</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/cremoteparams.ui" line="711"/>
        <source>save parameter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CRtspParams</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/crtspparams.cpp" line="55"/>
        <source>Get Rtsp fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/crtspparams.cpp" line="55"/>
        <source>Get Rtsp fail. &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/crtspparams.cpp" line="65"/>
        <source>SetRtsp fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/crtspparams.cpp" line="65"/>
        <source>Set Rtsp fail. &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CRtspParamsClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/crtspparams.ui" line="14"/>
        <source>CRtspParams</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/crtspparams.ui" line="26"/>
        <source>刷新</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/crtspparams.ui" line="39"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/crtspparams.ui" line="52"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/crtspparams.ui" line="68"/>
        <source>RTSP端口</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CSerialParams</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="26"/>
        <source>232串口配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="38"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="400"/>
        <source>速率</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="51"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="413"/>
        <source>数据位</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="64"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="374"/>
        <source>停止位</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="77"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="387"/>
        <source>校验</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="90"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="361"/>
        <source>流控</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="103"/>
        <source>操作模式</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="123"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="497"/>
        <source>50</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="128"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="502"/>
        <source>75</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="133"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="507"/>
        <source>110</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="138"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="512"/>
        <source>150</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="143"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="517"/>
        <source>300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="148"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="522"/>
        <source>600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="153"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="527"/>
        <source>1200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="158"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="532"/>
        <source>2400</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="163"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="537"/>
        <source>4800</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="168"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="542"/>
        <source>9600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="173"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="547"/>
        <source>19200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="178"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="552"/>
        <source>38400</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="183"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="557"/>
        <source>57600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="188"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="562"/>
        <source>76800</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="193"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="567"/>
        <source>115.2k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="208"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="582"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="213"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="587"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="218"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="592"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="223"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="597"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="238"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="427"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="243"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="432"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="258"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="447"/>
        <source>无校验</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="263"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="452"/>
        <source>奇校验</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="268"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="457"/>
        <source>偶校验</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="283"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="472"/>
        <source>无</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="288"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="477"/>
        <source>软流控</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="293"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="482"/>
        <source>硬流控</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="308"/>
        <source>窄带传输</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="313"/>
        <source>控制台</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="318"/>
        <source>透明通道</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="335"/>
        <source>窄带传输电话拨号配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="349"/>
        <source>RS485配置信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="611"/>
        <source>解码器类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="624"/>
        <source>解码器地址</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="638"/>
        <source>YouLi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="643"/>
        <source>LiLin-1016</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="648"/>
        <source>LiLin-820</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="653"/>
        <source>Pelco-p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="658"/>
        <source>DM DynaColor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="663"/>
        <source>HD600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="668"/>
        <source>JC-4116</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="673"/>
        <source>Pelco-d WX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="678"/>
        <source>Pelco-d PICO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="683"/>
        <source>VCOM_VC_2000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="688"/>
        <source>NETSTREAMER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="693"/>
        <source>SAE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="698"/>
        <source>SAMSUNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="703"/>
        <source>KALATEL_KTD_312</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="708"/>
        <source>CELOTEX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="713"/>
        <source>TLPELCO_P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="718"/>
        <source>TL_HHX2000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="723"/>
        <source>BBV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="728"/>
        <source>RM110</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="733"/>
        <source>KC3360S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="738"/>
        <source>ACES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="743"/>
        <source>ALSON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="748"/>
        <source>INV3609HD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="753"/>
        <source>HOWELL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="758"/>
        <source>TC_PELCO_P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="763"/>
        <source>TC_PELCO_D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="768"/>
        <source>AUTO_M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="773"/>
        <source>AUTO_H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="778"/>
        <source>ANTEN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="783"/>
        <source>CHANGLIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="788"/>
        <source>DELTADOME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="793"/>
        <source>XYM_12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="798"/>
        <source>ADR8060</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="803"/>
        <source>EVI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="808"/>
        <source>Demo_Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="813"/>
        <source>DM_PELCO_D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="818"/>
        <source>ST_832</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="823"/>
        <source>LC_D2104</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="828"/>
        <source>HUNTER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="833"/>
        <source>A01</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="838"/>
        <source>TECHWIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="843"/>
        <source>WEIHAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="848"/>
        <source>LG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="853"/>
        <source>D_MAX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="858"/>
        <source>PANASONIC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="863"/>
        <source>KTD_348</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="868"/>
        <source>INFINOVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="873"/>
        <source>PIH-7625</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="878"/>
        <source>IDOME/IVIEW/LCU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="883"/>
        <source>Dennar_dDome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="888"/>
        <source>Philips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="893"/>
        <source>SAMPLE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="898"/>
        <source>PLD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="903"/>
        <source>PARCO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="908"/>
        <source>HY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="913"/>
        <source>NAIJIE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="918"/>
        <source>YH_06</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="923"/>
        <source>SP9096X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="928"/>
        <source>M_PANEL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="933"/>
        <source>M_MV2050</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="938"/>
        <source>SAE_QUICK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="943"/>
        <source>RED_APPLE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="948"/>
        <source>NKO8G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="953"/>
        <source>DH_CC440</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="958"/>
        <source>TX_CONTROL_232</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="963"/>
        <source>VCL_SPEED_DOME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="968"/>
        <source>ST_2C160</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="973"/>
        <source>TDWY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="978"/>
        <source>TWHC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="983"/>
        <source>USNT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="988"/>
        <source>KLT_NVD2200PS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="993"/>
        <source>VIDO_B01</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="998"/>
        <source>LG_MULTIX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1003"/>
        <source>ENKEL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1008"/>
        <source>YT_PELCOD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1013"/>
        <source>HIKVISION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1018"/>
        <source>PE60</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1023"/>
        <source>LiAo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1028"/>
        <source>NK16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1033"/>
        <source>DaLi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1038"/>
        <source>HN_4304</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1043"/>
        <source>VIDEOTEC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1048"/>
        <source>HNDCB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1053"/>
        <source>Lion_2007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1058"/>
        <source>LG_LVC_C372</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1063"/>
        <source>Gold_Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1068"/>
        <source>NVD1600PS</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1095"/>
        <source>通道号</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1115"/>
        <source>刷新</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/SerialParams/cserialparams.ui" line="1128"/>
        <source>保存</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CShelterClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cshelter.ui" line="14"/>
        <source>CShelter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cshelter.ui" line="36"/>
        <source>confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cshelter.ui" line="49"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#ff0000;&quot;&gt;(size：704*576)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CUserParams</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="82"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="165"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="211"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="254"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="417"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="424"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="436"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="521"/>
        <source>Please check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="82"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="165"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="211"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="417"/>
        <source>Get User parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="254"/>
        <source>Get device parameters error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="424"/>
        <source>password is not equal error! </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="436"/>
        <source>ip is error! </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.cpp" line="521"/>
        <source>Set User parameters error! &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CUserParamsClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="14"/>
        <source>CUserParams</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="29"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; color:#0000ff;&quot;&gt;设备本地权限&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="59"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; color:#0000ff;&quot;&gt;客户端远程权限&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="135"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="337"/>
        <source>权限类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="159"/>
        <source>用户</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="173"/>
        <source>用户名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="187"/>
        <source>优先级</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="201"/>
        <source>密码</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="215"/>
        <source>确认密码</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="242"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="252"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="262"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="272"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="282"/>
        <source>：</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="306"/>
        <source>允许IP地址</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="318"/>
        <source>允许物理地址</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="359"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="488"/>
        <source>升级、格式化</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="366"/>
        <source>本地查看参数</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="373"/>
        <source>本地IP接入配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="380"/>
        <source>本地备份</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="387"/>
        <source>本地重启和关机</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="406"/>
        <source>本地云台控制</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="413"/>
        <source>本地录像</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="420"/>
        <source>本地回放</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="427"/>
        <source>本地设置参数</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="434"/>
        <source>本地查看状态，日志</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="453"/>
        <source>云台控制</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="460"/>
        <source>远程手动录像</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="467"/>
        <source>远程回放</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="474"/>
        <source>设置参数</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="481"/>
        <source>查看状态、日志</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="495"/>
        <source>语音对讲</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="514"/>
        <source>远程预览</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="521"/>
        <source>报警上传、输出</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="528"/>
        <source>远程控制本地输出</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="535"/>
        <source>远程控制串口</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="542"/>
        <source>保留</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="549"/>
        <source>远程IP接入配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/UserParams/cuserparams.ui" line="556"/>
        <source>远程重启、关机</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CVILostClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="14"/>
        <source>CVILost</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="26"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;Alarm handling mode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="59"/>
        <source>show alarm on monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="66"/>
        <source>audio alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="73"/>
        <source>report to center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="96"/>
        <source>confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="109"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#0000ff;&quot;&gt;Guard time&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="144"/>
        <source>period1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="151"/>
        <source>period2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="158"/>
        <source>peiod3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="165"/>
        <source>period4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="172"/>
        <source>period5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="179"/>
        <source>period6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="186"/>
        <source>period7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="193"/>
        <source>period8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="204"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="211"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="218"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="225"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="232"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="239"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="246"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="253"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="390"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="397"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="404"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="411"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="418"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="425"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="432"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="439"/>
        <source>h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="267"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="274"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="281"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="288"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="295"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="302"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="309"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="316"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="453"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="460"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="467"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="474"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="481"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="488"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="495"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="502"/>
        <source>min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="526"/>
        <source>trigger alarm out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="548"/>
        <source>date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="80"/>
        <source>Email JPEG     </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="327"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="334"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="341"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="348"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="355"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="362"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="369"/>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ChannelParams/cvilost.ui" line="376"/>
        <source>---</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CZoneDst</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.cpp" line="101"/>
        <source>Please check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.cpp" line="101"/>
        <source>.Get Zone information unsuccessfully!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.cpp" line="131"/>
        <source>Set Zone fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.cpp" line="131"/>
        <source>Set Zone fail. &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CZoneDstClass</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.ui" line="14"/>
        <source>CZoneDst</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.ui" line="44"/>
        <source>启用夏令时</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.ui" line="51"/>
        <source>夏令时偏移</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.ui" line="82"/>
        <source>起始时间点</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.ui" line="89"/>
        <source>停止时间点</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.ui" line="96"/>
        <source>月份</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.ui" line="113"/>
        <source>周</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.ui" line="126"/>
        <source>星期</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.ui" line="139"/>
        <source>小时</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.ui" line="152"/>
        <source>分钟</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.ui" line="174"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.ui" line="187"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/NetParams/czonedst.ui" line="200"/>
        <source>刷新</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChannelAttrClass</name>
    <message>
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="14"/>
        <source>ChannelAttr</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="49"/>
        <source>设备地址</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="62"/>
        <source>传输协议</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="75"/>
        <source>设备名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="89"/>
        <source>TCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="94"/>
        <source>UDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="99"/>
        <source>Mcast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="104"/>
        <source>RTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="109"/>
        <source>RTP/RTSP</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="146"/>
        <source>传输类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="182"/>
        <source>确认</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="196"/>
        <source>主码流</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="201"/>
        <source>子码流</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="228"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="251"/>
        <source>通道名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/MainWindow/DeviceTree/ChannelAttr/channelattr.ui" line="264"/>
        <source>通道号</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Deploy</name>
    <message>
        <location filename="../src/OtherFunc/Deployment/deploy.cpp" line="114"/>
        <source>NET_DVR_SetupAlarmChan_V50 failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/Deployment/deploy.cpp" line="115"/>
        <location filename="../src/OtherFunc/Deployment/deploy.cpp" line="128"/>
        <source>SDK_Last_Error =%1 </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/Deployment/deploy.cpp" line="118"/>
        <location filename="../src/OtherFunc/Deployment/deploy.cpp" line="119"/>
        <source>NET_DVR_SetupAlarmChan_V50 SUCCESS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/Deployment/deploy.cpp" line="127"/>
        <source>NET_DVR_CloseAlarmChan_V30 failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/Deployment/deploy.cpp" line="132"/>
        <location filename="../src/OtherFunc/Deployment/deploy.cpp" line="133"/>
        <source>NET_DVR_CloseAlarmChan_V30 SUCCESS</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeployClass</name>
    <message>
        <location filename="../src/OtherFunc/Deployment/deploy.ui" line="13"/>
        <source>Deploy</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/Deployment/deploy.ui" line="25"/>
        <source>布防/撤防</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/Deployment/deploy.ui" line="38"/>
        <source>退出</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/Deployment/deploy.ui" line="52"/>
        <source>设备树</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceAttrClass</name>
    <message>
        <location filename="../src/MainWindow/DeviceTree/DeviceAttr/deviceattr.ui" line="14"/>
        <source>DeviceAttr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/DeviceAttr/deviceattr.ui" line="36"/>
        <source>ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/DeviceAttr/deviceattr.ui" line="49"/>
        <source>serial No.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/DeviceAttr/deviceattr.ui" line="82"/>
        <source>device type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/DeviceAttr/deviceattr.ui" line="105"/>
        <source>channel num</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/DeviceAttr/deviceattr.ui" line="138"/>
        <source>IP address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/DeviceAttr/deviceattr.ui" line="164"/>
        <source>cannel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/DeviceAttr/deviceattr.ui" line="200"/>
        <source>username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/DeviceAttr/deviceattr.ui" line="213"/>
        <source>password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/DeviceAttr/deviceattr.ui" line="239"/>
        <source>port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/DeviceAttr/deviceattr.ui" line="252"/>
        <source>device name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/DeviceTree/DeviceAttr/deviceattr.ui" line="275"/>
        <source>multicast</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DevicePan</name>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.cpp" line="51"/>
        <source>NET_DVR_ClickKey Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.cpp" line="52"/>
        <location filename="../src/OtherFunc/DevicePan/devicepan.cpp" line="69"/>
        <location filename="../src/OtherFunc/DevicePan/devicepan.cpp" line="86"/>
        <source>SDK_LASTERROR=%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.cpp" line="68"/>
        <source>NET_DVR_LockPanel Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.cpp" line="85"/>
        <source>NET_DVR_UnLockPanel Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DevicePanClass</name>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="13"/>
        <source>DevicePan</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="25"/>
        <source>开始</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="38"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="51"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="64"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="77"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="90"/>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="545"/>
        <source>云台控制</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="103"/>
        <source>本地面板加锁</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="116"/>
        <source>本地面板解锁</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="194"/>
        <source>远程面板按钮</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="207"/>
        <source>11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="220"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="233"/>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="246"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="259"/>
        <source>15</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="272"/>
        <source>14</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="285"/>
        <source>16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="298"/>
        <source>13</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="311"/>
        <source>放像</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="324"/>
        <source>编辑</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="337"/>
        <source>录像</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="350"/>
        <source>主菜单</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="363"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="376"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="389"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="402"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="415"/>
        <source>ENTER</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="428"/>
        <source>输入法</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="441"/>
        <source>ESC</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="454"/>
        <source>多画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="467"/>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="727"/>
        <source>下</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="480"/>
        <source>对讲</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="493"/>
        <source>系统信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="506"/>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="714"/>
        <source>上</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="519"/>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="753"/>
        <source>右</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="532"/>
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="740"/>
        <source>左</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="623"/>
        <source>停止</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="636"/>
        <source>光圈 +</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="649"/>
        <source>光圈 -</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="662"/>
        <source>聚焦 +</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="675"/>
        <source>聚焦 -</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="688"/>
        <source>变倍 +</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="701"/>
        <source>变倍-</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/DevicePan/devicepan.ui" line="766"/>
        <source>退出</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceState</name>
    <message>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="39"/>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="258"/>
        <source>NET_DVR_GetDVRWorkState failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="40"/>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="259"/>
        <source>SDK_Last_Error =%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="113"/>
        <source>Cameral%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="118"/>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="122"/>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="128"/>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="132"/>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="139"/>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="143"/>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="192"/>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="196"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="147"/>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="151"/>
        <source>%1 </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/DeviceState/devicestate.cpp" line="188"/>
        <source>DISK%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceStateClass</name>
    <message>
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="13"/>
        <source>DeviceState</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="25"/>
        <source>通道状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="38"/>
        <source>总链接数</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="51"/>
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="325"/>
        <source>设备状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="147"/>
        <source>硬盘号</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="152"/>
        <source>硬盘容量(MB）</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="157"/>
        <source>剩余空间(MB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="162"/>
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="351"/>
        <source>硬盘状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="176"/>
        <source>设备节点名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="203"/>
        <source>通道号 </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="208"/>
        <source>录像状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="213"/>
        <source>信号状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="218"/>
        <source>硬件状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="223"/>
        <source>连接数</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="228"/>
        <source>当前码率</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="233"/>
        <source>IPC链接数</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="247"/>
        <source>退出</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="286"/>
        <source>设备IP地址</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/DeviceState/devicestate.ui" line="377"/>
        <source>刷新</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExceptionParams</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ExceptionParams/exceptionparams.cpp" line="161"/>
        <source>Succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ExceptionParams/exceptionparams.cpp" line="161"/>
        <source>NET_DVR_SET_EXCEPTIONCFG_V30 succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ExceptionParams/exceptionparams.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ExceptionParams/exceptionparams.ui" line="26"/>
        <source>异常配置信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ExceptionParams/exceptionparams.ui" line="38"/>
        <source>异常类型：</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ExceptionParams/exceptionparams.ui" line="61"/>
        <source>报警处理方式</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ExceptionParams/exceptionparams.ui" line="73"/>
        <source>监视器上警告</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ExceptionParams/exceptionparams.ui" line="86"/>
        <source>声音警告</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ExceptionParams/exceptionparams.ui" line="99"/>
        <source>上传中心</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ExceptionParams/exceptionparams.ui" line="112"/>
        <source>触发报警输出</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ExceptionParams/exceptionparams.ui" line="136"/>
        <source>刷新</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ParaConfig/configure_params/RemoteParams/ExceptionParams/exceptionparams.ui" line="149"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExitDemoClass</name>
    <message>
        <location filename="../src/ExitModule/exitdemo.ui" line="13"/>
        <source>ExitDemo</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ExitModule/exitdemo.ui" line="25"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ExitModule/exitdemo.ui" line="38"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ExitModule/exitdemo.ui" line="51"/>
        <source>确定要退出吗?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormatDisk</name>
    <message>
        <location filename="../src/ManageDevice/Format/formatdisk.cpp" line="32"/>
        <source>NET_DVR_GetDVRConfig failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Format/formatdisk.cpp" line="33"/>
        <location filename="../src/ManageDevice/Format/formatdisk.cpp" line="99"/>
        <location filename="../src/ManageDevice/Format/formatdisk.cpp" line="115"/>
        <source>SDK_Last_Error =%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Format/formatdisk.cpp" line="98"/>
        <source>NET_DVR_FormatDisk failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Format/formatdisk.cpp" line="114"/>
        <source>NET_DVR_GetFormatProgress failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Format/formatdisk.cpp" line="127"/>
        <source>NET_DVR_GetFormatProgress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Format/formatdisk.cpp" line="128"/>
        <source>FORMAT SUCCESS OVER format=%1 </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormatDiskClass</name>
    <message>
        <location filename="../src/ManageDevice/Format/formatdisk.ui" line="13"/>
        <source>FormatDisk</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Format/formatdisk.ui" line="35"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt;&quot;&gt;硬盘盘符&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Format/formatdisk.ui" line="52"/>
        <source>格式化</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Format/formatdisk.ui" line="65"/>
        <source>退出</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportConfig</name>
    <message>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.cpp" line="107"/>
        <source>µ¼³öÅäÖÃÎÄ¼þ´íÎó</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.cpp" line="108"/>
        <source>ÇëÑ¡¶¨Ò»Ì¨Éè±¸</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.cpp" line="145"/>
        <source>NET_DVR_GetConfigFile_V30 failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.cpp" line="146"/>
        <source>len SDK_Last_Error =%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.cpp" line="155"/>
        <source>NET_DVR_GetConfigFile failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.cpp" line="156"/>
        <source>file SDK_Last_Error =%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.cpp" line="161"/>
        <source>NET_DVR_GetConfigFile_V30 succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.cpp" line="162"/>
        <source>NET_DVR_GetConfigFile succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.cpp" line="179"/>
        <source>NET_DVR_SetConfigFile failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.cpp" line="180"/>
        <source>SDK_Last_Error =%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.cpp" line="183"/>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.cpp" line="184"/>
        <source>NET_DVR_SetConfigFile succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.cpp" line="210"/>
        <source>Find Config Files DIR and Filename</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportConfigClass</name>
    <message>
        <location filename="../src/OtherFunc/ImportConfig/importconfig.ui" line="13"/>
        <source>ImportConfig</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/ImportConfig/importconfig.ui" line="26"/>
        <source>设备树</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/ImportConfig/importconfig.ui" line="144"/>
        <source>导出配置文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/ImportConfig/importconfig.ui" line="157"/>
        <source>导入配置文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/ImportConfig/importconfig.ui" line="196"/>
        <source>配置文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/ImportConfig/importconfig.ui" line="209"/>
        <source>配置文件名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/ImportConfig/importconfig.ui" line="232"/>
        <source>浏览</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/ImportConfig/importconfig.ui" line="245"/>
        <source>导出</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/ImportConfig/importconfig.ui" line="268"/>
        <source>导入到勾选的设备</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/ImportConfig/importconfig.ui" line="281"/>
        <source>从上面的设备树中勾选一台设备</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/ImportConfig/importconfig.ui" line="304"/>
        <source>退出</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogSearch</name>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="216"/>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="231"/>
        <source>NET_DVR_FindDVRLog_V30 failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="217"/>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="232"/>
        <source>SDK_Last_Error =%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="245"/>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="253"/>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="259"/>
        <source>NET_DVR_FindDVRLog_V30</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="246"/>
        <source>NET_DVR_FILE_NOFIND</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="254"/>
        <source>NET_DVR_NOMOREFILE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="260"/>
        <source>NET_DVR_FILE_EXCEPTION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="295"/>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="333"/>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="342"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.cpp" line="329"/>
        <source>%1 </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogSearchClass</name>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="13"/>
        <source>LogSearch</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="38"/>
        <source>设备IP地址</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="74"/>
        <source>设备节点名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="176"/>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="206"/>
        <source>全部</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="181"/>
        <source>按类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="186"/>
        <source>按时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="191"/>
        <source>按时间和类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="211"/>
        <source>报警</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="216"/>
        <source>异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="221"/>
        <source>操作</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="226"/>
        <source>信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="241"/>
        <source>ALL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="246"/>
        <source>MINOR_ALARM_IN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="251"/>
        <source>MINOR_ALARM_OUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="256"/>
        <source>MINOR_MOTDET_START</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="261"/>
        <source>MINOR_MOTDET_STOP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="266"/>
        <source>MINOR_HIDE_ALARM_START</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="271"/>
        <source>MINOR_HIDE_ALARM_STOP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="276"/>
        <source>MINOR_VCA_ALARM_START</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="281"/>
        <source>MINOR_VCA_ALARM_STOP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="286"/>
        <source>---Excp-------</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="291"/>
        <source>MINOR_VI_LOST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="296"/>
        <source>MINOR_ILLEGAL_ACCESS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="301"/>
        <source>MINOR_HD_FULL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="306"/>
        <source>MINOR_HD_ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="311"/>
        <source>MINOR_DCD_LOST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="316"/>
        <source>MINOR_IP_CONFLICT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="321"/>
        <source>MINOR_NET_BROKEN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="326"/>
        <source>MINOR_REC_ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="331"/>
        <source>MINOR_IPC_NO_LINK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="336"/>
        <source>MINOR_VI_EXCEPTION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="341"/>
        <source>MINOR_IPC_IP_CONFLICT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="346"/>
        <source>----Oper-----</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="351"/>
        <source>MINOR_START_DVR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="356"/>
        <source>MINOR_STOP_DVR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="361"/>
        <source>MINOR_STOP_ABNORMAL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="366"/>
        <source>MINOR_REBOOT_DVR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="371"/>
        <source>MINOR_LOCAL_LOGIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="376"/>
        <source>MINOR_LOCAL_LOGOUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="381"/>
        <source>MINOR_LOCAL_CFG_PARM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="386"/>
        <source>MINOR_LOCAL_PLAYBYFILE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="391"/>
        <source>MINOR_LOCAL_PLAYBYTIME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="396"/>
        <source>MINOR_LOCAL_START_REC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="401"/>
        <source>MINOR_LOCAL_STOP_REC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="406"/>
        <source>MINOR_LOCAL_PTZCTRL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="411"/>
        <source>MINOR_LOCAL_PREVIEW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="416"/>
        <source>MINOR_LOCAL_MODIFY_TIME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="421"/>
        <source>MINOR_LOCAL_UPGRADE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="426"/>
        <source>MINOR_LOCAL_RECFILE_OUTPUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="431"/>
        <source>MINOR_LOCAL_FORMAT_HDD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="436"/>
        <source>MINOR_LOCAL_CFGFILE_OUTPUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="441"/>
        <source>MINOR_LOCAL_CFGFILE_INPUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="446"/>
        <source>----MINOR_LOCAL_COPYFILE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="451"/>
        <source>MINOR_LOCAL_LOCKFILE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="456"/>
        <source>MINOR_LOCAL_UNLOCKFILE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="461"/>
        <source>MINOR_LOCAL_DVR_ALARM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="466"/>
        <source>MINOR_IPC_ADD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="471"/>
        <source>MINOR_IPC_DEL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="476"/>
        <source>MINOR_IPC_SET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="481"/>
        <source>MINOR_LOCAL_START_BACKUP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="486"/>
        <source>MINOR_LOCAL_STOP_BACKUP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="491"/>
        <source>MINOR_LOCAL_COPYFILE_START_TIME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="496"/>
        <source>MINOR_LOCAL_COPYFILE_END_TIME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="501"/>
        <source>MINOR_LOCAL_ADD_NAS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="506"/>
        <source>MINOR_LOCAL_DEL_NAS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="511"/>
        <source>MINOR_LOCAL_SET_NAS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="516"/>
        <source>MINOR_REMOTE_LOGIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="521"/>
        <source>MINOR_REMOTE_LOGOUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="526"/>
        <source>MINOR_REMOTE_START_REC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="531"/>
        <source>MINOR_REMOTE_STOP_REC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="536"/>
        <source>MINOR_START_TRANS_CHAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="541"/>
        <source>MINOR_STOP_TRANS_CHAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="546"/>
        <source>MINOR_REMOTE_GET_PARM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="551"/>
        <source>MINOR_REMOTE_CFG_PARM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="556"/>
        <source>MINOR_REMOTE_GET_STATUS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="561"/>
        <source>MINOR_REMOTE_ARM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="566"/>
        <source>MINOR_REMOTE_DISARM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="571"/>
        <source>MINOR_REMOTE_REBOOT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="576"/>
        <source>MINOR_START_VT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="581"/>
        <source>MINOR_STOP_VT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="586"/>
        <source>MINOR_REMOTE_UPGRADE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="591"/>
        <source>MINOR_REMOTE_PLAYBYFILE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="596"/>
        <source>MINOR_REMOTE_PLAYBYTIME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="601"/>
        <source>MINOR_REMOTE_PTZCTRL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="606"/>
        <source>MINOR_REMOTE_FORMAT_HDD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="611"/>
        <source>MINOR_REMOTE_STOP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="616"/>
        <source>MINOR_REMOTE_LOCKFILE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="621"/>
        <source>MINOR_REMOTE_UNLOCKFILE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="626"/>
        <source>MINOR_REMOTE_CFGFILE_OUTPUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="631"/>
        <source>MINOR_REMOTE_CFGFILE_INTPUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="636"/>
        <source>MINOR_REMOTE_RECFILE_OUTPUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="641"/>
        <source>MINOR_REMOTE_IPC_ADD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="646"/>
        <source>MINOR_REMOTE_IPC_DEL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="651"/>
        <source>MINOR_REMOTE_IPC_SET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="656"/>
        <source>MINOR_REBOOT_VCA_LIB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="661"/>
        <source>MINOR_REMOTE_ADD_NAS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="666"/>
        <source>MINOR_REMOTE_DEL_NAS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="671"/>
        <source>MINOR_REMOTE_SET_NAS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="676"/>
        <source>-----Info----</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="681"/>
        <source>MINOR_HDD_INFO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="686"/>
        <source>MINOR_SMART_INFO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="691"/>
        <source>MINOR_REC_START</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="696"/>
        <source>MINOR_REC_STOP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="701"/>
        <source>MINOR_REC_OVERDUE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="706"/>
        <source>MINOR_LINK_START</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="711"/>
        <source>MINOR_LINK_STOP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="716"/>
        <source>MINOR_NET_DISK_INFO</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="730"/>
        <source>查询类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="743"/>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="814"/>
        <source>主类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="756"/>
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="819"/>
        <source>次类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="769"/>
        <source>开始时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="782"/>
        <source>结束时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="795"/>
        <source>硬盘smart信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="809"/>
        <source>日志时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="824"/>
        <source>远程主机</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="829"/>
        <source>描述</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="843"/>
        <source>搜索日志</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="856"/>
        <source>退出</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/LogSearch/logsearch.ui" line="869"/>
        <source>搜索日志中.......</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogTableClass</name>
    <message>
        <location filename="../src/MainWindow/LogAlarm/LogTable/logtable.ui" line="14"/>
        <source>LogTable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/LogAlarm/LogTable/logtable.ui" line="27"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/LogAlarm/LogTable/logtable.ui" line="32"/>
        <source>state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/LogAlarm/LogTable/logtable.ui" line="37"/>
        <source>operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/LogAlarm/LogTable/logtable.ui" line="42"/>
        <source>devicee info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow/LogAlarm/LogTable/logtable.ui" line="47"/>
        <source>error info</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayBack</name>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="207"/>
        <location filename="../src/PlayBack/playback.cpp" line="208"/>
        <location filename="../src/PlayBack/playback.cpp" line="332"/>
        <location filename="../src/PlayBack/playback.cpp" line="333"/>
        <source>Set SDL_WINDOWID failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="362"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="397"/>
        <location filename="../src/PlayBack/playback.cpp" line="428"/>
        <source>%1%2%3%4%5%6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="466"/>
        <location filename="../src/PlayBack/playback.cpp" line="1139"/>
        <location filename="../src/PlayBack/playback.cpp" line="1319"/>
        <location filename="../src/PlayBack/playback.cpp" line="1345"/>
        <location filename="../src/PlayBack/playback.cpp" line="2014"/>
        <location filename="../src/PlayBack/playback.cpp" line="2240"/>
        <location filename="../src/PlayBack/playback.cpp" line="2327"/>
        <location filename="../src/PlayBack/playback.cpp" line="2421"/>
        <source>NET_DVR_PlayBackControl failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="467"/>
        <location filename="../src/PlayBack/playback.cpp" line="549"/>
        <location filename="../src/PlayBack/playback.cpp" line="923"/>
        <location filename="../src/PlayBack/playback.cpp" line="957"/>
        <location filename="../src/PlayBack/playback.cpp" line="985"/>
        <location filename="../src/PlayBack/playback.cpp" line="997"/>
        <location filename="../src/PlayBack/playback.cpp" line="1050"/>
        <location filename="../src/PlayBack/playback.cpp" line="1140"/>
        <location filename="../src/PlayBack/playback.cpp" line="1283"/>
        <location filename="../src/PlayBack/playback.cpp" line="1320"/>
        <location filename="../src/PlayBack/playback.cpp" line="1346"/>
        <location filename="../src/PlayBack/playback.cpp" line="2015"/>
        <location filename="../src/PlayBack/playback.cpp" line="2021"/>
        <location filename="../src/PlayBack/playback.cpp" line="2035"/>
        <location filename="../src/PlayBack/playback.cpp" line="2087"/>
        <location filename="../src/PlayBack/playback.cpp" line="2187"/>
        <location filename="../src/PlayBack/playback.cpp" line="2241"/>
        <location filename="../src/PlayBack/playback.cpp" line="2328"/>
        <location filename="../src/PlayBack/playback.cpp" line="2354"/>
        <location filename="../src/PlayBack/playback.cpp" line="2422"/>
        <source>SDK_Last_Error =%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="548"/>
        <source>PlayBackByName failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="779"/>
        <source>PlayBack SearchFile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="780"/>
        <source>Malloc Error in PlayBack!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="810"/>
        <source> NET_DVR_FindFile_V30 </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="811"/>
        <source>SDK_LASTERROR=%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="830"/>
        <location filename="../src/PlayBack/playback.cpp" line="837"/>
        <location filename="../src/PlayBack/playback.cpp" line="846"/>
        <location filename="../src/PlayBack/playback.cpp" line="853"/>
        <location filename="../src/PlayBack/playback.cpp" line="860"/>
        <source> NET_DVR_FindFile_V30</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="831"/>
        <source>No file find!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="838"/>
        <source>Is finding now,wait a moment!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="847"/>
        <source>No more file find!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="854"/>
        <source>File Exception!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="861"/>
        <source>Error occured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="885"/>
        <source>GetFileByName Finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="886"/>
        <source>Please Select A File To Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="922"/>
        <location filename="../src/PlayBack/playback.cpp" line="956"/>
        <source>GetFileByName failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="942"/>
        <source>GetFileByName succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="942"/>
        <source>download finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1578"/>
        <source>finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1583"/>
        <source>no matching file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="984"/>
        <source>NET_DVR_LockFileByName failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="996"/>
        <source>NET_DVR_UnlockFileByName failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1019"/>
        <location filename="../src/PlayBack/playback.cpp" line="2062"/>
        <source>Save the playback file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1024"/>
        <location filename="../src/PlayBack/playback.cpp" line="2067"/>
        <source>directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1025"/>
        <location filename="../src/PlayBack/playback.cpp" line="2068"/>
        <source>directory =%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1030"/>
        <location filename="../src/PlayBack/playback.cpp" line="2073"/>
        <source>NET_DVR_PlayBackSaveData failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1031"/>
        <location filename="../src/PlayBack/playback.cpp" line="2074"/>
        <source>SDK_Last_Error =%1 m_pbhandle=%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1049"/>
        <location filename="../src/PlayBack/playback.cpp" line="2086"/>
        <source>NET_DVR_StopPlayBackSave failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1053"/>
        <location filename="../src/PlayBack/playback.cpp" line="1054"/>
        <location filename="../src/PlayBack/playback.cpp" line="2090"/>
        <location filename="../src/PlayBack/playback.cpp" line="2091"/>
        <source>NET_DVR_StopPlayBackSave succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1282"/>
        <location filename="../src/PlayBack/playback.cpp" line="2353"/>
        <source>NET_DVR_PlayBackCaptureFile failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1286"/>
        <location filename="../src/PlayBack/playback.cpp" line="2357"/>
        <source>NET_DVR_PlayBackCaptureFile succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1287"/>
        <location filename="../src/PlayBack/playback.cpp" line="2358"/>
        <source>NET_DVR_PlayBackCaptureFile success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1577"/>
        <source>Search File SUCC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1582"/>
        <source>Search File Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1601"/>
        <location filename="../src/PlayBack/playback.cpp" line="1602"/>
        <source>delete file succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1617"/>
        <location filename="../src/PlayBack/playback.cpp" line="1618"/>
        <source>delete all files succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1841"/>
        <location filename="../src/PlayBack/playback.cpp" line="1842"/>
        <source>Capture Picture succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="2020"/>
        <source>NET_DVR_GetFileByTime failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="2034"/>
        <source>NET_DVR_StopGetFile failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="2186"/>
        <source>NET_DVR_PlayBackByTime failed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayBackClass</name>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="14"/>
        <source>PlayBack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="30"/>
        <source>Tab 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="81"/>
        <location filename="../src/PlayBack/playback.ui" line="1033"/>
        <location filename="../src/PlayBack/playback.cpp" line="1128"/>
        <location filename="../src/PlayBack/playback.cpp" line="2229"/>
        <location filename="../src/PlayBack/playback.cpp" line="2279"/>
        <source>play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="104"/>
        <source>card No.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="123"/>
        <location filename="../src/PlayBack/playback.ui" line="905"/>
        <location filename="../src/PlayBack/playback.ui" line="1393"/>
        <source>snap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="142"/>
        <location filename="../src/PlayBack/playback.ui" line="1145"/>
        <location filename="../src/PlayBack/playback.ui" line="1431"/>
        <source>stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="155"/>
        <source>offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="169"/>
        <location filename="../src/PlayBack/playback.ui" line="1073"/>
        <source>file name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="174"/>
        <location filename="../src/PlayBack/playback.ui" line="1078"/>
        <source>size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="179"/>
        <location filename="../src/PlayBack/playback.ui" line="1088"/>
        <source>start time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="184"/>
        <location filename="../src/PlayBack/playback.ui" line="1093"/>
        <source>end time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="189"/>
        <source>property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="204"/>
        <location filename="../src/PlayBack/playback.ui" line="569"/>
        <location filename="../src/PlayBack/playback.ui" line="988"/>
        <source>all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="209"/>
        <source>unlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="214"/>
        <location filename="../src/PlayBack/playback.ui" line="403"/>
        <source>lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="228"/>
        <source>file length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="270"/>
        <location filename="../src/PlayBack/playback.ui" line="750"/>
        <location filename="../src/PlayBack/playback.ui" line="1450"/>
        <source>frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="309"/>
        <source>by card No.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="322"/>
        <location filename="../src/PlayBack/playback.ui" line="974"/>
        <source>download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="335"/>
        <source>download file name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="442"/>
        <source>file property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="465"/>
        <location filename="../src/PlayBack/playback.ui" line="1014"/>
        <location filename="../src/PlayBack/playback.ui" line="1236"/>
        <source>end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="484"/>
        <location filename="../src/PlayBack/playback.ui" line="795"/>
        <location filename="../src/PlayBack/playback.ui" line="1287"/>
        <source>fast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="497"/>
        <location filename="../src/PlayBack/playback.ui" line="1001"/>
        <source>search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="510"/>
        <source>buckup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="523"/>
        <source>record type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="542"/>
        <location filename="../src/PlayBack/playback.ui" line="937"/>
        <location filename="../src/PlayBack/playback.ui" line="1329"/>
        <source>reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="555"/>
        <location filename="../src/PlayBack/playback.ui" line="918"/>
        <location filename="../src/PlayBack/playback.ui" line="1268"/>
        <location filename="../src/PlayBack/playback.ui" line="1412"/>
        <source>start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="574"/>
        <source>schedule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="579"/>
        <source>motion dectect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="584"/>
        <location filename="../src/PlayBack/playback.ui" line="969"/>
        <source>alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="589"/>
        <source>alarm or motion dectect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="594"/>
        <source>alarm anf motion dectect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="599"/>
        <source>command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="604"/>
        <source>manual record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="618"/>
        <source>stop backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="637"/>
        <location filename="../src/PlayBack/playback.ui" line="886"/>
        <location filename="../src/PlayBack/playback.ui" line="1348"/>
        <source>slow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="700"/>
        <location filename="../src/PlayBack/playback.ui" line="1195"/>
        <location filename="../src/PlayBack/playback.ui" line="1516"/>
        <source>open volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="731"/>
        <source>file type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="776"/>
        <source>delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="857"/>
        <source>delete all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="964"/>
        <source>normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="1083"/>
        <source>type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="1223"/>
        <source>downlosd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="1300"/>
        <source>backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="706"/>
        <source>Tab 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.ui" line="1201"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="76"/>
        <source>remote file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="80"/>
        <source>local file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="84"/>
        <source>playback by time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1102"/>
        <location filename="../src/PlayBack/playback.cpp" line="1150"/>
        <location filename="../src/PlayBack/playback.cpp" line="1179"/>
        <location filename="../src/PlayBack/playback.cpp" line="2201"/>
        <location filename="../src/PlayBack/playback.cpp" line="2251"/>
        <source>pause</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PtzCruise</name>
    <message>
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.cpp" line="93"/>
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.cpp" line="99"/>
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.cpp" line="105"/>
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.cpp" line="122"/>
        <source>NET_DVR_PTZControl Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.cpp" line="94"/>
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.cpp" line="100"/>
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.cpp" line="106"/>
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.cpp" line="123"/>
        <source>SDK_LASTERROR=%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PtzCruiseClass</name>
    <message>
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.ui" line="13"/>
        <source>PtzCruise</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.ui" line="25"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:11pt;&quot;&gt;巡航路径&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.ui" line="51"/>
        <source>退出</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.ui" line="90"/>
        <source>删除巡航点</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.ui" line="116"/>
        <source>添加巡航点</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.ui" line="142"/>
        <source>巡航点</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.ui" line="155"/>
        <source>预置点</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.ui" line="168"/>
        <source>时间(秒)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/RealPlay/PTZ/PtzCruise/ptzcruise.ui" line="181"/>
        <source>速度</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PtzPreset</name>
    <message>
        <location filename="../src/RealPlay/PTZ/PtzPreset/ptzpreset.cpp" line="65"/>
        <location filename="../src/RealPlay/PTZ/PtzPreset/ptzpreset.cpp" line="90"/>
        <source>NET_DVR_PTZControl Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/PTZ/PtzPreset/ptzpreset.cpp" line="66"/>
        <location filename="../src/RealPlay/PTZ/PtzPreset/ptzpreset.cpp" line="91"/>
        <source>SDK_LASTERROR=%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PtzPresetClass</name>
    <message>
        <location filename="../src/RealPlay/PTZ/PtzPreset/ptzpreset.ui" line="14"/>
        <source>PtzPreset</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/RealPlay/PTZ/PtzPreset/ptzpreset.ui" line="26"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:11pt;&quot;&gt;预置点&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/RealPlay/PTZ/PtzPreset/ptzpreset.ui" line="53"/>
        <source>退出</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/RealPlay/PTZ/PtzPreset/ptzpreset.ui" line="92"/>
        <source>删除</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/RealPlay/PTZ/PtzPreset/ptzpreset.ui" line="118"/>
        <source>添加</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/ParaConfig/configure_params/PublicFuc/publicfuc.cpp" line="429"/>
        <source>Please check!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtClientDemo</name>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="467"/>
        <location filename="../src/qtclientdemo.cpp" line="627"/>
        <source>file error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="468"/>
        <location filename="../src/qtclientdemo.cpp" line="628"/>
        <source>open device tree file error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="491"/>
        <source>SDK INITIAL ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="492"/>
        <location filename="../src/qtclientdemo.cpp" line="874"/>
        <location filename="../src/qtclientdemo.cpp" line="948"/>
        <location filename="../src/qtclientdemo.cpp" line="1726"/>
        <source>SDK_LAST_ERROR=%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="874"/>
        <location filename="../src/qtclientdemo.cpp" line="948"/>
        <location filename="../src/qtclientdemo.cpp" line="1401"/>
        <source>NET_DVR_Login_V40</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1402"/>
        <source>µÇÂ½Éè±¸Ê§°Ü£¬´íÎóÂë = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1406"/>
        <source>NET_DVR_Login_V40 SUCC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1440"/>
        <source>have no login yet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1440"/>
        <source>not login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1447"/>
        <source>logout error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1460"/>
        <source>NET_DVR_Logout_V30</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1488"/>
        <source>DeleteError!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1489"/>
        <source>There are channel RealPlay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1262"/>
        <source>system message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1262"/>
        <source>add or delete device success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1387"/>
        <source>login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1387"/>
        <source>already login!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1406"/>
        <location filename="../src/qtclientdemo.cpp" line="1460"/>
        <source>login success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1447"/>
        <source>preview not stopped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1537"/>
        <source>error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1537"/>
        <source>this device is not in the device list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1686"/>
        <source>login fail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1687"/>
        <source>error code=%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1725"/>
        <source>NET_DVR_GetDVRConfig</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1949"/>
        <location filename="../src/qtclientdemo.cpp" line="1950"/>
        <source>modify channel attr error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="2403"/>
        <source>ÊÖ¶¯Â¼ÏñÉèÖÃÊ§°Ü</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="2404"/>
        <location filename="../src/qtclientdemo.cpp" line="2430"/>
        <source>SDK_LASTERROR=[%1]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="2408"/>
        <location filename="../src/qtclientdemo.cpp" line="2447"/>
        <source>NET_DVR_StartDVRRecord SUCC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="2409"/>
        <location filename="../src/qtclientdemo.cpp" line="2448"/>
        <source>ÊÖ¶¯Â¼ÏñÉèÖÃ³É¹¦</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="2429"/>
        <source>NET_DVR_StartDVRRecord Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtClientDemoClass</name>
    <message>
        <location filename="../src/qtclientdemo.ui" line="26"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.ui" line="203"/>
        <source>playback</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/qtclientdemo.ui" line="255"/>
        <source>QT_DEMO：   1.1.0
HIK_SDK ：   4.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.ui" line="52"/>
        <source>management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.ui" line="65"/>
        <source>save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.ui" line="91"/>
        <source>other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.ui" line="154"/>
        <source>exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.ui" line="216"/>
        <source>alarm info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.ui" line="242"/>
        <source>local log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.ui" line="269"/>
        <source>clean</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/qtclientdemo.ui" line="282"/>
        <location filename="../src/qtclientdemo.ui" line="289"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.ui" line="296"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.ui" line="309"/>
        <source>test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.ui" line="400"/>
        <source>preview</source>
        <translatorcomment>预览</translatorcomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.ui" line="426"/>
        <source>list config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.ui" line="439"/>
        <source>configure</source>
        <translatorcomment>配置</translatorcomment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RealPlay</name>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="253"/>
        <source>DrawAreaInit failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="242"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="242"/>
        <source>Set SDL_WINDOWID failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="253"/>
        <source>Error code:&quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="674"/>
        <location filename="../src/RealPlay/realplay.cpp" line="693"/>
        <source>NET_DVR_RealPlay_V40 error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="674"/>
        <location filename="../src/RealPlay/realplay.cpp" line="994"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1027"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1131"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1148"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1190"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1224"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1238"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1263"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1489"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1522"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1531"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1565"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1582"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1599"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1618"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1648"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1727"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1751"/>
        <source>SDK_LASTERROR=%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="686"/>
        <source>NET_DVR_GetDVRConfig</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="687"/>
        <source>SDK_LAST_ERROR=%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="694"/>
        <source>¸ÃÍ¨µÀ²»ÔÚÏß£¬Ô¤ÀÀÊ§°Ü</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="900"/>
        <source>stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="967"/>
        <source>ÉèÖÃ³ö´í</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="968"/>
        <source>ÇëÏÈÍ£Ö¹²¥·ÅÔÙÐÞ¸Ä´ò¿ª´°¿ÚÊý</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="986"/>
        <source>SET REAL QUALITY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="987"/>
        <source>CURRENT CHANNEL NUM IS NOT REALPLAYING!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="993"/>
        <location filename="../src/RealPlay/realplay.cpp" line="999"/>
        <source>NET_DVR_SetPlayerBufNumber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1000"/>
        <source>SET SUCCESSFULLY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1026"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1262"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1488"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1521"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1530"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1564"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1581"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1598"/>
        <source>NET_DVR_PTZControl Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1071"/>
        <source>have no login yet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1071"/>
        <source>not login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1107"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1171"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1210"/>
        <source>have no realplay yet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1108"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1172"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1211"/>
        <source>Please Play Video First!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1130"/>
        <source>NET_DVR_SaveRealData Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1147"/>
        <source>NET_DVR_StopSaveRealData Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1189"/>
        <source>NET_DVR_CapturePicture Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1194"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1195"/>
        <source>NET_DVR_CapturePicture succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1223"/>
        <source>NET_DVR_MakeKeyFrame Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1228"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1229"/>
        <source>NET_DVR_MakeKeyFrame succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1237"/>
        <source>NET_DVR_MakeKeyFrameSub Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1242"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1243"/>
        <source>NET_DVR_MakeKeyFrameSub succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1617"/>
        <source>NET_DVR_ClientGetVideoEffect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1647"/>
        <source>NET_DVR_ClientSetVideoEffect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1726"/>
        <source>ÓïÒô²ÎÊýÉèÖÃ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1750"/>
        <source>NET_DVR_Volume</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RealPlayClass</name>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="26"/>
        <source>RealPlay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="39"/>
        <location filename="../src/RealPlay/realplay.ui" line="816"/>
        <location filename="../src/RealPlay/realplay.ui" line="2140"/>
        <location filename="../src/RealPlay/realplay.ui" line="3443"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="44"/>
        <location filename="../src/RealPlay/realplay.ui" line="831"/>
        <location filename="../src/RealPlay/realplay.ui" line="2155"/>
        <location filename="../src/RealPlay/realplay.ui" line="3458"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="49"/>
        <location filename="../src/RealPlay/realplay.ui" line="856"/>
        <location filename="../src/RealPlay/realplay.ui" line="2180"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="54"/>
        <location filename="../src/RealPlay/realplay.ui" line="891"/>
        <location filename="../src/RealPlay/realplay.ui" line="2215"/>
        <source>16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="59"/>
        <location filename="../src/RealPlay/realplay.ui" line="936"/>
        <location filename="../src/RealPlay/realplay.ui" line="2260"/>
        <source>25</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="64"/>
        <location filename="../src/RealPlay/realplay.ui" line="991"/>
        <location filename="../src/RealPlay/realplay.ui" line="2315"/>
        <source>36</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="78"/>
        <source>focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="117"/>
        <source>preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="169"/>
        <source>window num</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="247"/>
        <location filename="../src/RealPlay/realplay.ui" line="607"/>
        <location filename="../src/RealPlay/realplay.ui" line="672"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="286"/>
        <source>PTZ sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="312"/>
        <location filename="../src/RealPlay/realplay.cpp" line="1153"/>
        <source>record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="338"/>
        <source>PTZ control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="351"/>
        <source>right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="364"/>
        <source>zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="403"/>
        <source>record cruise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="429"/>
        <source>saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="442"/>
        <location filename="../src/RealPlay/realplay.ui" line="3438"/>
        <source>default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="455"/>
        <source>left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="468"/>
        <source>network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="481"/>
        <source>create I frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="494"/>
        <location filename="../src/RealPlay/realplay.ui" line="3552"/>
        <source>call</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="520"/>
        <source>down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="547"/>
        <source>most realtime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="552"/>
        <source>more realtime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="557"/>
        <source>realtime,smooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="562"/>
        <source>more smooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="567"/>
        <source>most smooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="581"/>
        <source>volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="594"/>
        <location filename="../src/RealPlay/realplay.ui" line="737"/>
        <source>set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="620"/>
        <source>hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="659"/>
        <source>contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="698"/>
        <source>up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="724"/>
        <location filename="../src/RealPlay/realplay.ui" line="2126"/>
        <location filename="../src/RealPlay/realplay.ui" line="3500"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="750"/>
        <source>snapshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="763"/>
        <source>brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="776"/>
        <source>run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="821"/>
        <location filename="../src/RealPlay/realplay.ui" line="2145"/>
        <location filename="../src/RealPlay/realplay.ui" line="3448"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="826"/>
        <location filename="../src/RealPlay/realplay.ui" line="2150"/>
        <location filename="../src/RealPlay/realplay.ui" line="3453"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="836"/>
        <location filename="../src/RealPlay/realplay.ui" line="2160"/>
        <location filename="../src/RealPlay/realplay.ui" line="3463"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="841"/>
        <location filename="../src/RealPlay/realplay.ui" line="2165"/>
        <location filename="../src/RealPlay/realplay.ui" line="3468"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="846"/>
        <location filename="../src/RealPlay/realplay.ui" line="2170"/>
        <location filename="../src/RealPlay/realplay.ui" line="3473"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="851"/>
        <location filename="../src/RealPlay/realplay.ui" line="2175"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="861"/>
        <location filename="../src/RealPlay/realplay.ui" line="2185"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="866"/>
        <location filename="../src/RealPlay/realplay.ui" line="2190"/>
        <source>11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="871"/>
        <location filename="../src/RealPlay/realplay.ui" line="2195"/>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="876"/>
        <location filename="../src/RealPlay/realplay.ui" line="2200"/>
        <source>13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="881"/>
        <location filename="../src/RealPlay/realplay.ui" line="2205"/>
        <source>14</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="886"/>
        <location filename="../src/RealPlay/realplay.ui" line="2210"/>
        <source>15</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="896"/>
        <location filename="../src/RealPlay/realplay.ui" line="2220"/>
        <source>17</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="901"/>
        <location filename="../src/RealPlay/realplay.ui" line="2225"/>
        <source>18</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="906"/>
        <location filename="../src/RealPlay/realplay.ui" line="2230"/>
        <source>19</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="911"/>
        <location filename="../src/RealPlay/realplay.ui" line="2235"/>
        <source>20</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="916"/>
        <location filename="../src/RealPlay/realplay.ui" line="2240"/>
        <source>21</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="921"/>
        <location filename="../src/RealPlay/realplay.ui" line="2245"/>
        <source>22</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="926"/>
        <location filename="../src/RealPlay/realplay.ui" line="2250"/>
        <source>23</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="931"/>
        <location filename="../src/RealPlay/realplay.ui" line="2255"/>
        <source>24</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="941"/>
        <location filename="../src/RealPlay/realplay.ui" line="2265"/>
        <source>26</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="946"/>
        <location filename="../src/RealPlay/realplay.ui" line="2270"/>
        <source>27</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="951"/>
        <location filename="../src/RealPlay/realplay.ui" line="2275"/>
        <source>28</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="956"/>
        <location filename="../src/RealPlay/realplay.ui" line="2280"/>
        <source>29</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="961"/>
        <location filename="../src/RealPlay/realplay.ui" line="2285"/>
        <source>30</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="966"/>
        <location filename="../src/RealPlay/realplay.ui" line="2290"/>
        <source>31</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="971"/>
        <location filename="../src/RealPlay/realplay.ui" line="2295"/>
        <source>32</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="976"/>
        <location filename="../src/RealPlay/realplay.ui" line="2300"/>
        <source>33</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="981"/>
        <location filename="../src/RealPlay/realplay.ui" line="2305"/>
        <source>34</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="986"/>
        <location filename="../src/RealPlay/realplay.ui" line="2310"/>
        <source>35</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="996"/>
        <location filename="../src/RealPlay/realplay.ui" line="2320"/>
        <source>37</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1001"/>
        <location filename="../src/RealPlay/realplay.ui" line="2325"/>
        <source>38</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1006"/>
        <location filename="../src/RealPlay/realplay.ui" line="2330"/>
        <source>39</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1011"/>
        <location filename="../src/RealPlay/realplay.ui" line="2335"/>
        <source>40</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1016"/>
        <location filename="../src/RealPlay/realplay.ui" line="2340"/>
        <source>41</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1021"/>
        <location filename="../src/RealPlay/realplay.ui" line="2345"/>
        <source>42</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1026"/>
        <location filename="../src/RealPlay/realplay.ui" line="2350"/>
        <source>43</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1031"/>
        <location filename="../src/RealPlay/realplay.ui" line="2355"/>
        <source>44</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1036"/>
        <location filename="../src/RealPlay/realplay.ui" line="2360"/>
        <source>45</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1041"/>
        <location filename="../src/RealPlay/realplay.ui" line="2365"/>
        <source>46</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1046"/>
        <location filename="../src/RealPlay/realplay.ui" line="2370"/>
        <source>47</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1051"/>
        <location filename="../src/RealPlay/realplay.ui" line="2375"/>
        <source>48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1056"/>
        <location filename="../src/RealPlay/realplay.ui" line="2380"/>
        <source>49</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1061"/>
        <location filename="../src/RealPlay/realplay.ui" line="2385"/>
        <source>50</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1066"/>
        <location filename="../src/RealPlay/realplay.ui" line="2390"/>
        <source>51</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1071"/>
        <location filename="../src/RealPlay/realplay.ui" line="2395"/>
        <source>52</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1076"/>
        <location filename="../src/RealPlay/realplay.ui" line="2400"/>
        <source>53</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1081"/>
        <location filename="../src/RealPlay/realplay.ui" line="2405"/>
        <source>54</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1086"/>
        <location filename="../src/RealPlay/realplay.ui" line="2410"/>
        <source>55</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1091"/>
        <location filename="../src/RealPlay/realplay.ui" line="2415"/>
        <source>56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1096"/>
        <location filename="../src/RealPlay/realplay.ui" line="2420"/>
        <source>57</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1101"/>
        <location filename="../src/RealPlay/realplay.ui" line="2425"/>
        <source>58</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1106"/>
        <location filename="../src/RealPlay/realplay.ui" line="2430"/>
        <source>59</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1111"/>
        <location filename="../src/RealPlay/realplay.ui" line="2435"/>
        <source>60</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1116"/>
        <location filename="../src/RealPlay/realplay.ui" line="2440"/>
        <source>61</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1121"/>
        <location filename="../src/RealPlay/realplay.ui" line="2445"/>
        <source>62</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1126"/>
        <location filename="../src/RealPlay/realplay.ui" line="2450"/>
        <source>63</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1131"/>
        <location filename="../src/RealPlay/realplay.ui" line="2455"/>
        <source>64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1136"/>
        <location filename="../src/RealPlay/realplay.ui" line="2460"/>
        <source>65</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1141"/>
        <location filename="../src/RealPlay/realplay.ui" line="2465"/>
        <source>66</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1146"/>
        <location filename="../src/RealPlay/realplay.ui" line="2470"/>
        <source>67</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1151"/>
        <location filename="../src/RealPlay/realplay.ui" line="2475"/>
        <source>68</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1156"/>
        <location filename="../src/RealPlay/realplay.ui" line="2480"/>
        <source>69</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1161"/>
        <location filename="../src/RealPlay/realplay.ui" line="2485"/>
        <source>70</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1166"/>
        <location filename="../src/RealPlay/realplay.ui" line="2490"/>
        <source>71</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1171"/>
        <location filename="../src/RealPlay/realplay.ui" line="2495"/>
        <source>72</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1176"/>
        <location filename="../src/RealPlay/realplay.ui" line="2500"/>
        <source>73</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1181"/>
        <location filename="../src/RealPlay/realplay.ui" line="2505"/>
        <source>74</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1186"/>
        <location filename="../src/RealPlay/realplay.ui" line="2510"/>
        <source>75</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1191"/>
        <location filename="../src/RealPlay/realplay.ui" line="2515"/>
        <source>76</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1196"/>
        <location filename="../src/RealPlay/realplay.ui" line="2520"/>
        <source>77</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1201"/>
        <location filename="../src/RealPlay/realplay.ui" line="2525"/>
        <source>78</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1206"/>
        <location filename="../src/RealPlay/realplay.ui" line="2530"/>
        <source>79</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1211"/>
        <location filename="../src/RealPlay/realplay.ui" line="2535"/>
        <source>80</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1216"/>
        <location filename="../src/RealPlay/realplay.ui" line="2540"/>
        <source>81</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1221"/>
        <location filename="../src/RealPlay/realplay.ui" line="2545"/>
        <source>82</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1226"/>
        <location filename="../src/RealPlay/realplay.ui" line="2550"/>
        <source>83</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1231"/>
        <location filename="../src/RealPlay/realplay.ui" line="2555"/>
        <source>84</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1236"/>
        <location filename="../src/RealPlay/realplay.ui" line="2560"/>
        <source>85</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1241"/>
        <location filename="../src/RealPlay/realplay.ui" line="2565"/>
        <source>86</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1246"/>
        <location filename="../src/RealPlay/realplay.ui" line="2570"/>
        <source>87</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1251"/>
        <location filename="../src/RealPlay/realplay.ui" line="2575"/>
        <source>88</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1256"/>
        <location filename="../src/RealPlay/realplay.ui" line="2580"/>
        <source>89</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1261"/>
        <location filename="../src/RealPlay/realplay.ui" line="2585"/>
        <source>90</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1266"/>
        <location filename="../src/RealPlay/realplay.ui" line="2590"/>
        <source>91</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1271"/>
        <location filename="../src/RealPlay/realplay.ui" line="2595"/>
        <source>92</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1276"/>
        <location filename="../src/RealPlay/realplay.ui" line="2600"/>
        <source>93</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1281"/>
        <location filename="../src/RealPlay/realplay.ui" line="2605"/>
        <source>94</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1286"/>
        <location filename="../src/RealPlay/realplay.ui" line="2610"/>
        <source>95</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1291"/>
        <location filename="../src/RealPlay/realplay.ui" line="2615"/>
        <source>96</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1296"/>
        <location filename="../src/RealPlay/realplay.ui" line="2620"/>
        <source>97</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1301"/>
        <location filename="../src/RealPlay/realplay.ui" line="2625"/>
        <source>98</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1306"/>
        <location filename="../src/RealPlay/realplay.ui" line="2630"/>
        <source>99</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1311"/>
        <location filename="../src/RealPlay/realplay.ui" line="2635"/>
        <source>100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1316"/>
        <location filename="../src/RealPlay/realplay.ui" line="2640"/>
        <source>101</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1321"/>
        <location filename="../src/RealPlay/realplay.ui" line="2645"/>
        <source>102</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1326"/>
        <location filename="../src/RealPlay/realplay.ui" line="2650"/>
        <source>103</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1331"/>
        <location filename="../src/RealPlay/realplay.ui" line="2655"/>
        <source>104</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1336"/>
        <location filename="../src/RealPlay/realplay.ui" line="2660"/>
        <source>105</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1341"/>
        <location filename="../src/RealPlay/realplay.ui" line="2665"/>
        <source>106</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1346"/>
        <location filename="../src/RealPlay/realplay.ui" line="2670"/>
        <source>107</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1351"/>
        <location filename="../src/RealPlay/realplay.ui" line="2675"/>
        <source>108</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1356"/>
        <location filename="../src/RealPlay/realplay.ui" line="2680"/>
        <source>109</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1361"/>
        <location filename="../src/RealPlay/realplay.ui" line="2685"/>
        <source>110</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1366"/>
        <location filename="../src/RealPlay/realplay.ui" line="2690"/>
        <source>111</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1371"/>
        <location filename="../src/RealPlay/realplay.ui" line="2695"/>
        <source>112</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1376"/>
        <location filename="../src/RealPlay/realplay.ui" line="2700"/>
        <source>113</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1381"/>
        <location filename="../src/RealPlay/realplay.ui" line="2705"/>
        <source>114</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1386"/>
        <location filename="../src/RealPlay/realplay.ui" line="2710"/>
        <source>115</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1391"/>
        <location filename="../src/RealPlay/realplay.ui" line="2715"/>
        <source>116</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1396"/>
        <location filename="../src/RealPlay/realplay.ui" line="2720"/>
        <source>117</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1401"/>
        <location filename="../src/RealPlay/realplay.ui" line="2725"/>
        <source>118</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1406"/>
        <location filename="../src/RealPlay/realplay.ui" line="2730"/>
        <source>119</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1411"/>
        <location filename="../src/RealPlay/realplay.ui" line="2735"/>
        <source>120</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1416"/>
        <location filename="../src/RealPlay/realplay.ui" line="2740"/>
        <source>121</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1421"/>
        <location filename="../src/RealPlay/realplay.ui" line="2745"/>
        <source>122</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1426"/>
        <location filename="../src/RealPlay/realplay.ui" line="2750"/>
        <source>123</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1431"/>
        <location filename="../src/RealPlay/realplay.ui" line="2755"/>
        <source>124</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1436"/>
        <location filename="../src/RealPlay/realplay.ui" line="2760"/>
        <source>125</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1441"/>
        <location filename="../src/RealPlay/realplay.ui" line="2765"/>
        <source>126</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1446"/>
        <location filename="../src/RealPlay/realplay.ui" line="2770"/>
        <source>127</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1451"/>
        <location filename="../src/RealPlay/realplay.ui" line="2775"/>
        <source>128</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1456"/>
        <location filename="../src/RealPlay/realplay.ui" line="2780"/>
        <source>129</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1461"/>
        <location filename="../src/RealPlay/realplay.ui" line="2785"/>
        <source>130</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1466"/>
        <location filename="../src/RealPlay/realplay.ui" line="2790"/>
        <source>131</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1471"/>
        <location filename="../src/RealPlay/realplay.ui" line="2795"/>
        <source>132</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1476"/>
        <location filename="../src/RealPlay/realplay.ui" line="2800"/>
        <source>133</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1481"/>
        <location filename="../src/RealPlay/realplay.ui" line="2805"/>
        <source>134</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1486"/>
        <location filename="../src/RealPlay/realplay.ui" line="2810"/>
        <source>135</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1491"/>
        <location filename="../src/RealPlay/realplay.ui" line="2815"/>
        <source>136</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1496"/>
        <location filename="../src/RealPlay/realplay.ui" line="2820"/>
        <source>137</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1501"/>
        <location filename="../src/RealPlay/realplay.ui" line="2825"/>
        <source>138</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1506"/>
        <location filename="../src/RealPlay/realplay.ui" line="2830"/>
        <source>139</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1511"/>
        <location filename="../src/RealPlay/realplay.ui" line="2835"/>
        <source>140</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1516"/>
        <location filename="../src/RealPlay/realplay.ui" line="2840"/>
        <source>141</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1521"/>
        <location filename="../src/RealPlay/realplay.ui" line="2845"/>
        <source>142</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1526"/>
        <location filename="../src/RealPlay/realplay.ui" line="2850"/>
        <source>143</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1531"/>
        <location filename="../src/RealPlay/realplay.ui" line="2855"/>
        <source>144</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1536"/>
        <location filename="../src/RealPlay/realplay.ui" line="2860"/>
        <source>145</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1541"/>
        <location filename="../src/RealPlay/realplay.ui" line="2865"/>
        <source>146</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1546"/>
        <location filename="../src/RealPlay/realplay.ui" line="2870"/>
        <source>147</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1551"/>
        <location filename="../src/RealPlay/realplay.ui" line="2875"/>
        <source>148</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1556"/>
        <location filename="../src/RealPlay/realplay.ui" line="2880"/>
        <source>149</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1561"/>
        <location filename="../src/RealPlay/realplay.ui" line="2885"/>
        <source>150</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1566"/>
        <location filename="../src/RealPlay/realplay.ui" line="2890"/>
        <source>151</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1571"/>
        <location filename="../src/RealPlay/realplay.ui" line="2895"/>
        <source>152</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1576"/>
        <location filename="../src/RealPlay/realplay.ui" line="2900"/>
        <source>153</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1581"/>
        <location filename="../src/RealPlay/realplay.ui" line="2905"/>
        <source>154</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1586"/>
        <location filename="../src/RealPlay/realplay.ui" line="2910"/>
        <source>155</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1591"/>
        <location filename="../src/RealPlay/realplay.ui" line="2915"/>
        <source>156</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1596"/>
        <location filename="../src/RealPlay/realplay.ui" line="2920"/>
        <source>257</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1601"/>
        <location filename="../src/RealPlay/realplay.ui" line="2925"/>
        <source>158</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1606"/>
        <location filename="../src/RealPlay/realplay.ui" line="2930"/>
        <source>159</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1611"/>
        <location filename="../src/RealPlay/realplay.ui" line="2935"/>
        <source>160</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1616"/>
        <location filename="../src/RealPlay/realplay.ui" line="2940"/>
        <source>161</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1621"/>
        <location filename="../src/RealPlay/realplay.ui" line="2945"/>
        <source>162</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1626"/>
        <location filename="../src/RealPlay/realplay.ui" line="2950"/>
        <source>163</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1631"/>
        <location filename="../src/RealPlay/realplay.ui" line="2955"/>
        <source>164</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1636"/>
        <location filename="../src/RealPlay/realplay.ui" line="2960"/>
        <source>165</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1641"/>
        <location filename="../src/RealPlay/realplay.ui" line="2965"/>
        <source>166</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1646"/>
        <location filename="../src/RealPlay/realplay.ui" line="2970"/>
        <source>167</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1651"/>
        <location filename="../src/RealPlay/realplay.ui" line="2975"/>
        <source>168</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1656"/>
        <location filename="../src/RealPlay/realplay.ui" line="2980"/>
        <source>169</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1661"/>
        <location filename="../src/RealPlay/realplay.ui" line="2985"/>
        <source>170</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1666"/>
        <location filename="../src/RealPlay/realplay.ui" line="2990"/>
        <source>171</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1671"/>
        <location filename="../src/RealPlay/realplay.ui" line="2995"/>
        <source>172</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1676"/>
        <location filename="../src/RealPlay/realplay.ui" line="3000"/>
        <source>173</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1681"/>
        <location filename="../src/RealPlay/realplay.ui" line="3005"/>
        <source>174</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1686"/>
        <location filename="../src/RealPlay/realplay.ui" line="3010"/>
        <source>175</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1691"/>
        <location filename="../src/RealPlay/realplay.ui" line="3015"/>
        <source>176</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1696"/>
        <location filename="../src/RealPlay/realplay.ui" line="3020"/>
        <source>177</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1701"/>
        <location filename="../src/RealPlay/realplay.ui" line="3025"/>
        <source>178</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1706"/>
        <location filename="../src/RealPlay/realplay.ui" line="3030"/>
        <source>179</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1711"/>
        <location filename="../src/RealPlay/realplay.ui" line="3035"/>
        <source>180</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1716"/>
        <location filename="../src/RealPlay/realplay.ui" line="3040"/>
        <source>181</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1721"/>
        <location filename="../src/RealPlay/realplay.ui" line="3045"/>
        <source>182</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1726"/>
        <location filename="../src/RealPlay/realplay.ui" line="3050"/>
        <source>183</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1731"/>
        <location filename="../src/RealPlay/realplay.ui" line="3055"/>
        <source>184</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1736"/>
        <location filename="../src/RealPlay/realplay.ui" line="3060"/>
        <source>185</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1741"/>
        <location filename="../src/RealPlay/realplay.ui" line="3065"/>
        <source>186</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1746"/>
        <location filename="../src/RealPlay/realplay.ui" line="3070"/>
        <source>187</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1751"/>
        <location filename="../src/RealPlay/realplay.ui" line="3075"/>
        <source>188</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1756"/>
        <location filename="../src/RealPlay/realplay.ui" line="3080"/>
        <source>189</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1761"/>
        <location filename="../src/RealPlay/realplay.ui" line="3085"/>
        <source>190</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1766"/>
        <location filename="../src/RealPlay/realplay.ui" line="3090"/>
        <source>191</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1771"/>
        <location filename="../src/RealPlay/realplay.ui" line="3095"/>
        <source>192</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1776"/>
        <location filename="../src/RealPlay/realplay.ui" line="3100"/>
        <source>193</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1781"/>
        <location filename="../src/RealPlay/realplay.ui" line="3105"/>
        <source>194</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1786"/>
        <location filename="../src/RealPlay/realplay.ui" line="3110"/>
        <source>195</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1791"/>
        <location filename="../src/RealPlay/realplay.ui" line="3115"/>
        <source>196</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1796"/>
        <location filename="../src/RealPlay/realplay.ui" line="3120"/>
        <source>197</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1801"/>
        <location filename="../src/RealPlay/realplay.ui" line="3125"/>
        <source>198</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1806"/>
        <location filename="../src/RealPlay/realplay.ui" line="3130"/>
        <source>199</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1811"/>
        <location filename="../src/RealPlay/realplay.ui" line="3135"/>
        <source>200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1816"/>
        <location filename="../src/RealPlay/realplay.ui" line="3140"/>
        <source>201</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1821"/>
        <location filename="../src/RealPlay/realplay.ui" line="3145"/>
        <source>202</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1826"/>
        <location filename="../src/RealPlay/realplay.ui" line="3150"/>
        <source>203</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1831"/>
        <location filename="../src/RealPlay/realplay.ui" line="3155"/>
        <source>204</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1836"/>
        <location filename="../src/RealPlay/realplay.ui" line="3160"/>
        <source>205</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1841"/>
        <location filename="../src/RealPlay/realplay.ui" line="3165"/>
        <source>206</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1846"/>
        <location filename="../src/RealPlay/realplay.ui" line="3170"/>
        <source>207</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1851"/>
        <location filename="../src/RealPlay/realplay.ui" line="3175"/>
        <source>208</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1856"/>
        <location filename="../src/RealPlay/realplay.ui" line="3180"/>
        <source>209</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1861"/>
        <location filename="../src/RealPlay/realplay.ui" line="3185"/>
        <source>210</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1866"/>
        <location filename="../src/RealPlay/realplay.ui" line="3190"/>
        <source>211</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1871"/>
        <location filename="../src/RealPlay/realplay.ui" line="3195"/>
        <source>212</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1876"/>
        <location filename="../src/RealPlay/realplay.ui" line="3200"/>
        <source>213</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1881"/>
        <location filename="../src/RealPlay/realplay.ui" line="3205"/>
        <source>214</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1886"/>
        <location filename="../src/RealPlay/realplay.ui" line="3210"/>
        <source>215</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1891"/>
        <location filename="../src/RealPlay/realplay.ui" line="3215"/>
        <source>216</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1896"/>
        <location filename="../src/RealPlay/realplay.ui" line="3220"/>
        <source>217</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1901"/>
        <location filename="../src/RealPlay/realplay.ui" line="3225"/>
        <source>218</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1906"/>
        <location filename="../src/RealPlay/realplay.ui" line="3230"/>
        <source>219</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1911"/>
        <location filename="../src/RealPlay/realplay.ui" line="3235"/>
        <source>220</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1916"/>
        <location filename="../src/RealPlay/realplay.ui" line="3240"/>
        <source>221</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1921"/>
        <location filename="../src/RealPlay/realplay.ui" line="3245"/>
        <source>222</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1926"/>
        <location filename="../src/RealPlay/realplay.ui" line="3250"/>
        <source>223</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1931"/>
        <location filename="../src/RealPlay/realplay.ui" line="3255"/>
        <source>224</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1936"/>
        <location filename="../src/RealPlay/realplay.ui" line="3260"/>
        <source>225</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1941"/>
        <location filename="../src/RealPlay/realplay.ui" line="3265"/>
        <source>226</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1946"/>
        <location filename="../src/RealPlay/realplay.ui" line="3270"/>
        <source>227</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1951"/>
        <location filename="../src/RealPlay/realplay.ui" line="3275"/>
        <source>228</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1956"/>
        <location filename="../src/RealPlay/realplay.ui" line="3280"/>
        <source>229</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1961"/>
        <location filename="../src/RealPlay/realplay.ui" line="3285"/>
        <source>230</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1966"/>
        <location filename="../src/RealPlay/realplay.ui" line="3290"/>
        <source>231</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1971"/>
        <location filename="../src/RealPlay/realplay.ui" line="3295"/>
        <source>232</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1976"/>
        <location filename="../src/RealPlay/realplay.ui" line="3300"/>
        <source>233</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1981"/>
        <location filename="../src/RealPlay/realplay.ui" line="3305"/>
        <source>234</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1986"/>
        <location filename="../src/RealPlay/realplay.ui" line="3310"/>
        <source>235</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1991"/>
        <location filename="../src/RealPlay/realplay.ui" line="3315"/>
        <source>236</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="1996"/>
        <location filename="../src/RealPlay/realplay.ui" line="3320"/>
        <source>237</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2001"/>
        <location filename="../src/RealPlay/realplay.ui" line="3325"/>
        <source>238</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2006"/>
        <location filename="../src/RealPlay/realplay.ui" line="3330"/>
        <source>239</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2011"/>
        <location filename="../src/RealPlay/realplay.ui" line="3335"/>
        <source>240</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2016"/>
        <location filename="../src/RealPlay/realplay.ui" line="3340"/>
        <source>241</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2021"/>
        <location filename="../src/RealPlay/realplay.ui" line="3345"/>
        <source>242</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2026"/>
        <location filename="../src/RealPlay/realplay.ui" line="3350"/>
        <source>243</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2031"/>
        <location filename="../src/RealPlay/realplay.ui" line="3355"/>
        <source>244</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2036"/>
        <location filename="../src/RealPlay/realplay.ui" line="3360"/>
        <source>245</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2041"/>
        <location filename="../src/RealPlay/realplay.ui" line="3365"/>
        <source>246</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2046"/>
        <location filename="../src/RealPlay/realplay.ui" line="3370"/>
        <source>247</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2051"/>
        <location filename="../src/RealPlay/realplay.ui" line="3375"/>
        <source>248</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2056"/>
        <location filename="../src/RealPlay/realplay.ui" line="3380"/>
        <source>249</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2061"/>
        <location filename="../src/RealPlay/realplay.ui" line="3385"/>
        <source>250</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2066"/>
        <location filename="../src/RealPlay/realplay.ui" line="3390"/>
        <source>251</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2071"/>
        <location filename="../src/RealPlay/realplay.ui" line="3395"/>
        <source>252</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2076"/>
        <location filename="../src/RealPlay/realplay.ui" line="3400"/>
        <source>253</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2081"/>
        <location filename="../src/RealPlay/realplay.ui" line="3405"/>
        <source>254</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2086"/>
        <location filename="../src/RealPlay/realplay.ui" line="3410"/>
        <source>255</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2100"/>
        <source>stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="2113"/>
        <source>PTZ speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="3424"/>
        <source>start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="3526"/>
        <source>lris</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.ui" line="3539"/>
        <source>play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1136"/>
        <source>stop record</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RebootDevice</name>
    <message>
        <location filename="../src/ManageDevice/Reboot/rebootdevice.cpp" line="51"/>
        <source>NET_DVR_RebootDVR ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Reboot/rebootdevice.cpp" line="52"/>
        <source>SDK_Last_Error =%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RebootDeviceClass</name>
    <message>
        <location filename="../src/ManageDevice/Reboot/rebootdevice.ui" line="13"/>
        <source>RebootDevice</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Reboot/rebootdevice.ui" line="25"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Reboot/rebootdevice.ui" line="38"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Reboot/rebootdevice.ui" line="51"/>
        <source>确定要重启吗?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RemoteUpdate</name>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.cpp" line="74"/>
        <source>setnetworktype failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.cpp" line="75"/>
        <source>errorno=%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.cpp" line="79"/>
        <source>setnetworktype success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.cpp" line="80"/>
        <source>setnetworktype success.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.cpp" line="95"/>
        <source>Find Update Files DIR and Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.cpp" line="115"/>
        <source>NET_DVR_Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.cpp" line="145"/>
        <location filename="../src/ManageDevice/Update/remoteupdate.cpp" line="176"/>
        <source>Update failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.cpp" line="146"/>
        <source>&quot;%1&quot; is return value of 	NET_DVR_Upgrade.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.cpp" line="115"/>
        <location filename="../src/ManageDevice/Update/remoteupdate.cpp" line="172"/>
        <source>Update success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.cpp" line="172"/>
        <source>Update has success.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.cpp" line="177"/>
        <source>&quot;%1&quot; is return value of 	NET_DVR_GetUpgradeState.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RemoteUpdateClass</name>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.ui" line="14"/>
        <source>RemoteUpdate</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Update/remoteupdate.ui" line="26"/>
        <source>网络类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.ui" line="40"/>
        <source>LAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.ui" line="45"/>
        <source>WAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Update/remoteupdate.ui" line="59"/>
        <source>设置网络环境</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Update/remoteupdate.ui" line="72"/>
        <source>升级文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Update/remoteupdate.ui" line="95"/>
        <source>浏览</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Update/remoteupdate.ui" line="108"/>
        <source>升级</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Update/remoteupdate.ui" line="121"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Update/remoteupdate.ui" line="147"/>
        <source>upgrade state</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResetDevice</name>
    <message>
        <location filename="../src/ManageDevice/Reset/resetdevice.cpp" line="52"/>
        <source>NET_DVR_RestoreConfig ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Reset/resetdevice.cpp" line="53"/>
        <source>SDK_Last_Error =%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResetDeviceClass</name>
    <message>
        <location filename="../src/ManageDevice/Reset/resetdevice.ui" line="13"/>
        <source>ResetDevice</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Reset/resetdevice.ui" line="25"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Reset/resetdevice.ui" line="38"/>
        <source>确定要恢复默认参数?</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Reset/resetdevice.ui" line="51"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SerialTransfer</name>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="145"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="196"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="259"/>
        <source>NET_DVR_SerialStart ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="146"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="197"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="285"/>
        <source>SDK_Last_Error =%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="150"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="167"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="168"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="186"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="187"/>
        <source>NET_DVR_SerialSend success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="151"/>
        <source>NET_DVR_SerialSend 	success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="161"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="162"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="180"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="181"/>
        <source>NET_DVR_SerialSend failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="200"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="201"/>
        <source>NET_DVR_SendTo232Port success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="252"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="263"/>
        <source>NET_DVR_SerialStart succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="253"/>
        <source>NET_DVR_SerialStart has started already!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="260"/>
        <source>SDK_Last_Error =%1 *m_stuserid=%2 m_stserialtype=%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="264"/>
        <source>NET_DVR_SerialStart success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="278"/>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="290"/>
        <source>NET_DVR_SerialStop succ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="279"/>
        <source>NET_DVR_SerialStop has stopped already!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="284"/>
        <source>NET_DVR_SerialStop ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.cpp" line="291"/>
        <source>NET_DVR_SerialStop successfully</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SerialTransferClass</name>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="13"/>
        <source>SerialTransfer</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="25"/>
        <source>关闭透明通道</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="38"/>
        <source>启动透明通道</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="51"/>
        <source>通道号</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="64"/>
        <source>通道类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="181"/>
        <source>发送数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="233"/>
        <source>接收数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="285"/>
        <source>发送数据的接口</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="298"/>
        <source>发送</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="322"/>
        <source>时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="327"/>
        <source>内容</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="341"/>
        <source>退出</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="355"/>
        <source>232</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="360"/>
        <source>485</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="385"/>
        <source>NET_DVR_SerialSend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="390"/>
        <source>NET_DVR_SendToSerialPort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/OtherFunc/SerialTransfer/serialtransfer.ui" line="395"/>
        <source>NET_DVR_SendTo232Port</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShutdownDevice</name>
    <message>
        <location filename="../src/ManageDevice/Shutdown/shutdowndevice.cpp" line="52"/>
        <source>NET_DVR_ShutDownDVR ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Shutdown/shutdowndevice.cpp" line="53"/>
        <source>SDK_Last_Error =%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShutdownDeviceClass</name>
    <message>
        <location filename="../src/ManageDevice/Shutdown/shutdowndevice.ui" line="13"/>
        <source>ShutdownDevice</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Shutdown/shutdowndevice.ui" line="25"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Shutdown/shutdowndevice.ui" line="38"/>
        <source>确定要关闭设备?</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Shutdown/shutdowndevice.ui" line="51"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Timing</name>
    <message>
        <location filename="../src/ManageDevice/Timing/timing.cpp" line="93"/>
        <source>NET_DVR_SetDVRConfig failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Timing/timing.cpp" line="94"/>
        <source>SDK_Last_Error =%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Timing/timing.cpp" line="97"/>
        <source>NET_DVR_SET_TIMECFG SUCCESS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ManageDevice/Timing/timing.cpp" line="98"/>
        <source>SET_TIMECFG SUCCESS</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimingClass</name>
    <message>
        <location filename="../src/ManageDevice/Timing/timing.ui" line="13"/>
        <source>Timing</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Timing/timing.ui" line="26"/>
        <source>设备树</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Timing/timing.ui" line="40"/>
        <source>校时</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/ManageDevice/Timing/timing.ui" line="53"/>
        <source>退出</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TranslateClass</name>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="498"/>
        <location filename="../src/PlayBack/playback.cpp" line="989"/>
        <source>unlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="504"/>
        <location filename="../src/PlayBack/playback.cpp" line="1001"/>
        <source>lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RealPlay/realplay.cpp" line="1089"/>
        <source>play</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>translateClass</name>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="928"/>
        <source>stop download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="944"/>
        <location filename="../src/PlayBack/playback.cpp" line="961"/>
        <source>download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1233"/>
        <location filename="../src/PlayBack/playback.cpp" line="1773"/>
        <location filename="../src/PlayBack/playback.cpp" line="2399"/>
        <source>open volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PlayBack/playback.cpp" line="1242"/>
        <location filename="../src/PlayBack/playback.cpp" line="1764"/>
        <location filename="../src/PlayBack/playback.cpp" line="2390"/>
        <source>close volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/PlayBack/playback.cpp" line="2025"/>
        <source>停止下载</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/PlayBack/playback.cpp" line="2039"/>
        <source>下载</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/PlayBack/playback.cpp" line="2079"/>
        <source>停止保存</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/PlayBack/playback.cpp" line="2093"/>
        <source>保存</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/qtclientdemo.cpp" line="1088"/>
        <source>属性</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/qtclientdemo.cpp" line="1084"/>
        <source>抓图</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1058"/>
        <source>login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1062"/>
        <source>logout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1066"/>
        <source>delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="1070"/>
        <source>property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="2121"/>
        <source>check time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="2125"/>
        <source>upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="2129"/>
        <source>format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="2133"/>
        <source>restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="2137"/>
        <source>shut down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="2141"/>
        <source>query log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="2145"/>
        <source>device state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtclientdemo.cpp" line="2149"/>
        <source>restore default</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/qtclientdemo.cpp" line="2316"/>
        <source>布防撤防</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/qtclientdemo.cpp" line="2320"/>
        <source>手动录像</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/qtclientdemo.cpp" line="2324"/>
        <source>串口透传</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/qtclientdemo.cpp" line="2328"/>
        <source>设备面板</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/qtclientdemo.cpp" line="2332"/>
        <source>导入配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../src/qtclientdemo.cpp" line="2346"/>
        <source>语音转发</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
