1.请使用qt4.7版本，将lib下所有so文件拷贝到QtDemo/Linux32/lib，使用qtcreator编译生成QtClientDemo，双击运行
2.如果要在qtcreator调试运行，需要将lib/HCNetSDKCom文件夹拷贝到与Makefile同级目录下




	
  