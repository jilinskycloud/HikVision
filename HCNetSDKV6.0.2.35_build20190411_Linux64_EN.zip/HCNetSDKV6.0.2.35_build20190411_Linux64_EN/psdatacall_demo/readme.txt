1.The library all the Lib copy to the psdatacall_demo, including the HCNetSDKCom folder.
2.Fill in device information in the Device.ini file.
3.In the terminal input make to compile, and generate getpsdata,  using the./getpsdata to run.


