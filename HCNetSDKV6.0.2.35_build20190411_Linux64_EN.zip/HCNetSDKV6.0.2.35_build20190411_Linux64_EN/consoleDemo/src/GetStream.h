/*
* Copyright(C) 2010,Hikvision Digital Technology Co., Ltd 
* 
* File   name��GetStream.h
* Discription��
* Version    ��1.0
* Author     ��panyd
* Create Date��2010_3_25
* Modification History��
*/

#ifndef _GETSTREAM_H_
#define _GETSTREAM_H_

#include "public.h"

int Demo_GetStream();
int Demo_GetStream_V30(LONG lUserID);

void Demo_SDK_Ability();

void Demo_SDK_Version();


#endif
